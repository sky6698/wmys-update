# -*- coding: utf-8 -*-
"""TVBox py 源的本地桥服务（无名影视 Windows 版）。

一个独立的 Python 子进程，把「TVBox 生态的 py 源脚本」包装成和 Node 站点
服务一样的 HTTP 端点，界面（`CatpawClient`）不用区分站点是 JS 还是 py：

    POST /site/<key>/<action>    JSON in / JSON out
    action: init | home | category | detail | search | play

启动时打印 `PORT:<port>` 到 stdout，由 Dart 侧读走后拼接站点 api。

站点脚本按 `<sites>/<key>.py` 存放（订阅同步时下载）；同名 `<key>.json`
可选，里面放 `{"extend": "..."}`，对应 TVBox 的 `ext` 参数。
"""

import argparse
import ast
import atexit
import base64
import hashlib
import inspect
import io
import json
import os
import re
import signal
import sys
import threading
import time
import traceback
import unicodedata
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.machinery import SourceFileLoader
from urllib.parse import urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import base.spider as base_spider  # noqa: E402

# key -> spider 实例；key -> 互斥锁（py 源普遍有实例内状态，串行调用）
SPIDERS = {}
LOCKS = {}
REGISTRY_LOCK = threading.Lock()

# 最近一次被使用/加载的站点 key（第 71 批）。
# ★webhtv 的 `/proxy?do=py` 不带 siteKey 时用的是 PyLoader 里「最近那个」
# spider —— 瓜子这类源把 `PROXY_BASE` 写死成 `…/proxy?do=py` 也照样能取流。
LAST_SITE = ""

SITES_DIR = ""
CACHE_DIR = ""
PORT = 0

# 已取过的歌词 LRC 原文（song_id → text）；「重搜歌词」反复选中同一首不重跑。
LYRIC_CACHE = {}

# ---- 多源歌词搜索（第 53 批）---------------------------------------------
# 参考 webhtv 的 LyricsRepository：网易云 / QQ 音乐 / 酷狗 / 酷我 / LRCLIB
# **同时开搜**，每个源一个线程，谁先回来先落进结果集；界面按 token 轮询拿
# 快照，快照每次都重新排序 —— 后到的源分数更高就把头名挤下去（「最接近的
# 动态显示在最上边」）。
LYRIC_JOBS = {}
LYRIC_JOBS_LOCK = threading.Lock()
# 候选 id → 元数据：酷狗取词要 hash + 时长 + 关键词，元数据在搜索阶段才有。
LYRIC_META = {}
LYRIC_JOB_TTL = 120.0
LYRIC_JOB_MAX = 8
LYRIC_META_MAX = 600

# ★源内 UI 事件（第 163 批）：JVM 桩（AlertDialog / Toast / 二维码位图）把
# 「源以为自己在 Android 上弹的窗」POST 到 /hook/ui，先攒在这里；action
# 调用收尾时捎回给 App。只留最近几条，防 someone 疯狂弹窗把内存吃光。
UI_EVENTS = []
UI_EVENTS_LOCK = threading.Lock()
UI_EVENTS_MAX = 16
# ★第 165 批：事件带自增序号。源的「扫码成功」是几十秒后才发生的（源自己的
# 轮询线程），那时 action 早返回了 —— App 靠 POST /ui/poll 按序号续拉增量，
# 否则「百度网盘授权成功」这类迟到的提示永远送不到界面上（= 扫了没反应）。
UI_EVENT_SEQ = [0]

# ★第 181 批：双向对话框的挂起表。桩（AlertDialog 交互窗）POST 一条
# wait:true 的事件后**不挂电话**，等 App 画完窗、用户操作完 POST
# /ui/respond，这里把 {"button","values"} 回给那条挂起的 HTTP —— 桩的
# 守护线程醒来回填输入、触发源自己的按钮回调（蜂蜜 dialog.show 语义）。
UI_WAITERS = {}
UI_WAITERS_LOCK = threading.Lock()
UI_WAIT_SEQ = [0]
UI_WAIT_TIMEOUT = 300.0  # 用户填表单/扫码确认可能要好几分钟
# ★第 182 批：窗 id（桩自带的自增号）→ 桥的等待号。桩自己 dismiss 时
# 只知道窗 id（UiHook.cancelWait(id)），原来拿它当等待号查不到人 —— 那
# 条等待线程要白等到 300s 超时。这里建个反查表。
UI_WAIT_BY_DIALOG = {}


def waiter_respond(wait_id, resp):
    """把 App 的回传交给挂起的桩请求； False = 没这条 waiter（已超时/取消）。"""
    with UI_WAITERS_LOCK:
        waiter = UI_WAITERS.get(wait_id)
        if waiter is None:
            waiter = UI_WAITERS.get(UI_WAIT_BY_DIALOG.get(wait_id, ""))
        if waiter is None:
            return False
        waiter["resp"] = resp
        waiter["event"].set()
        return True

# 图片代理缓存目录（`<sites>/imgcache`）：豆瓣/番茄这类图存一份，别每次重抓转码。
IMG_CACHE_DIR = ""
# B 站这类源把 DASH 清单用 data: URI 塞在 play.url 里（第 54 批）。
# mpv 直接吃 data: 不可靠，统一落成本地 .mpd 再给 file:// 地址。
DASH_CACHE_DIR = ""
# 图床抓取用的 UA：豆瓣、番茄都按桌面浏览器放行。
IMG_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
# 歌词站的 UA 同上：QQ/酷我/酷狗都按桌面浏览器放行，python-requests 默认头会被挑。
LYRIC_UA = IMG_UA


def site_paths(key):
    py = os.path.join(SITES_DIR, key + ".py")
    cfg = os.path.join(SITES_DIR, key + ".json")
    return py, cfg


def read_extend(key):
    _, cfg = site_paths(key)
    if not os.path.exists(cfg):
        return ""
    try:
        with open(cfg, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return data.get("extend", "") or ""
    except Exception:
        pass
    return ""


def get_lock(key):
    with REGISTRY_LOCK:
        lock = LOCKS.get(key)
        if lock is None:
            lock = LOCKS[key] = threading.RLock()
        return lock


def get_spider(key, extend=None):
    """加载（首次）并返回某站点的 Spider 实例。"""
    global LAST_SITE
    with get_lock(key):
        LAST_SITE = key
        # ★`SITE_KEY` 是模块级全局：源里的 `getProxyUrl()` 每次现读。
        # 只在首次 import 时设的话，第二个站一加载就会把第一个站拼出来的
        # 代理地址换成别人的 key（表现为「代理 404 / 播到别人站的内容」）。
        base_spider.SITE_KEY = key
        spider = SPIDERS.get(key)
        if spider is not None:
            return spider
        # 第 140 批：jar 形态站点（名字以 `jar_` 开头）—— 实现不在 py 脚本里，
        # 而在订阅下下来的 spider jar 中，交给 jarsite 转给 JVM。
        if key.startswith("jar_"):
            import jarsite

            spider = jarsite.make_spider(key, SITES_DIR)
            SPIDERS[key] = spider
            ext = read_extend(key) if extend is None else extend
            try:
                spider.init(ext)
            except TypeError:
                spider.init()
            return spider
        py, _ = site_paths(key)
        if not os.path.exists(py):
            raise RuntimeError("站点脚本不存在：" + py)
        # py 源普遍写 `from base.spider import Spider`，脚本目录本身也要在路径上
        #（有些脚本会 `sys.path.append('..')` 再去 import 同目录的辅助模块）。
        if SITES_DIR not in sys.path:
            sys.path.insert(0, SITES_DIR)
        base_spider.PY_DIR = SITES_DIR
        base_spider.PROXY_PORT = PORT
        base_spider.SITE_KEY = key
        module = SourceFileLoader("pysite_" + key, py).load_module()
        spider = module.Spider()
        SPIDERS[key] = spider
        ext = read_extend(key) if extend is None else extend
        try:
            spider.init(ext)
        except TypeError:
            # 少数脚本的 init 不接参数。
            spider.init()
        return spider


def as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def call_spider(fn, *args):
    """按被调方法的签名裁剪实参。

    TVBox py 源的 `type` 写法很杂：`categoryContent(self, tid, pg, filter, extend)`
    是标准五参，但也有只写 `(self, tid, pg)`、`searchContent(self, key, quick)`
    （豆瓣就是这样，多传一个 `pg` 会 TypeError）的。TVBox 本体也是按需传参，
    所以这里照签名裁一刀，别让「参数多了」把整站打挂。
    """
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return fn(*args)
    params = [
        p
        for p in sig.parameters.values()
        if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
    ]
    if any(p.kind == p.VAR_POSITIONAL for p in sig.parameters.values()):
        return fn(*args)
    return fn(*args[: len(params)])


def norm_home(result):
    """homeContent / homeVideoContent → 统一结构。"""
    out = {}
    if isinstance(result, dict):
        out.update(result)
    out.setdefault("class", [])
    out.setdefault("filters", {})
    out.setdefault("list", [])
    return out


def as_int(value, fallback):
    """宽容取整数：TVBox py 源常把分页/parse 写成字符串（`"1"`、`"0"`）。"""
    if isinstance(value, bool):
        return fallback
    try:
        return int(str(value).strip())
    except Exception:
        return fallback


def norm_page(result, page):
    out = {}
    if isinstance(result, dict):
        out.update(result)
    out.setdefault("list", [])
    # ★归一成数字（第 45 批）：源给的 `"page": "1"` 原样透传会让 Dart 侧
    # `as num?` 强转抛 TypeError —— 现象是「推荐正常、其它分类全部拉取失败」
    # （home 不带分页字段，category 才带）。
    size = len(out["list"])
    out["page"] = as_int(out.get("page"), page)
    out["pagecount"] = as_int(out.get("pagecount"), 1)
    out["limit"] = as_int(out.get("limit"), size)
    out["total"] = as_int(out.get("total"), 0)
    return out


MEDIA_RE = re.compile(r"\.(?:m3u8|mp4|flv|m4a|mp3|ts)(?:$|\?)", re.I)
# 播放页里那一整串「第N集$地址#第N集$地址…$$$下一线路…」：整串不含空格/引号，
# 所以从一个 `$http` 处向左向右吃同词字符就够。
PLAY_BLOB_RE = re.compile(r"[^\s\"'<>]*\$https?://[^\s\"'<>]+\.(?:m3u8|mp4)[^\s\"'<>]*", re.I)
ONE_MEDIA_RE = re.compile(r"https?://[^\s\"'<>\\]+?\.(?:m3u8|mp4)[^\s\"'<>\\]*", re.I)
SRC_NUM_RE = re.compile(r"src-(\d+)-num-(\d+)")


def looks_media(url):
    return bool(MEDIA_RE.search(str(url or "").split("#")[0]))


def pick_episode(blob, play_id):
    """从整串播放列表里挑「当前这一集」。

    优先按播放页地址里的 `src-N-num-M` 定位（无名影视这类源就是这个形态：
    第 N 条线路的第 M 集）；认不出来就退第一条线路的第一集。
    """
    lines = [x for x in blob.split("$$$") if x.strip()]
    if not lines:
        return ""
    m = SRC_NUM_RE.search(str(play_id))
    line_idx = int(m.group(1)) - 1 if m else 0
    ep_idx = int(m.group(2)) - 1 if m else 0
    line_idx = max(0, min(line_idx, len(lines) - 1))
    episodes = [x for x in lines[line_idx].split("#") if x.strip()]
    if not episodes:
        return ""
    ep_idx = max(0, min(ep_idx, len(episodes) - 1))
    picked = episodes[ep_idx]
    # `名字$地址` 或纯地址两种写法
    return picked.split("$", 1)[1].strip() if "$" in picked else picked.strip()


def resolve_web_play(spider, data, play_id):
    """`parse != 0`（网页解析）的播放地址，抓页面把真地址挖出来。

    TVBox 遇到 `parse:1` 是把地址交给内置 webview 解析器去播；我们没有那套
    解析器，只能自己动手 —— 实测多数这类播放页（无名影视、部分苹果 CMS 皮）
    页面里就明文写着整串 m3u8（含所有线路所有集），挖出来直接播比找解析接口
    稳。挖不到就把原样返回，让界面老老实实报错，别假装能播。
    """
    url = str(data.get("url") or "")
    if not url.startswith("http") or looks_media(url):
        return data
    headers = data.get("header")
    if not isinstance(headers, dict) or not headers:
        headers = None
    try:
        rsp = spider.fetch(url, headers=headers, timeout=10, verify=False)
        text = rsp.text if rsp is not None else ""
    except Exception as exc:
        log_line("网页解析抓取失败：%s" % exc)
        return data
    if not text:
        return data

    blob = PLAY_BLOB_RE.search(text)
    if blob:
        picked = pick_episode(blob.group(0), play_id)
        if picked:
            out = dict(data)
            out["url"] = picked
            out["parse"] = 0
            out.setdefault("header", headers or {})
            log_line("网页解析命中播放列表：%s" % brief(picked, 80))
            return out
    single = ONE_MEDIA_RE.search(text)
    if single:
        out = dict(data)
        out["url"] = single.group(0)
        out["parse"] = 0
        out.setdefault("header", headers or {})
        log_line("网页解析命中单地址：%s" % brief(out["url"], 80))
        return out
    log_line("网页解析未挖到地址：%s" % brief(url, 60))
    return data


def _img_cache_paths(key):
    return (
        os.path.join(IMG_CACHE_DIR, key + ".dat"),
        os.path.join(IMG_CACHE_DIR, key + ".mime"),
    )


def _img_cache_read(key):
    data_path, mime_path = _img_cache_paths(key)
    if not (os.path.exists(data_path) and os.path.exists(mime_path)):
        return None
    try:
        with open(data_path, "rb") as fp:
            data = fp.read()
        with open(mime_path, "r", encoding="utf-8") as fp:
            mime = fp.read().strip() or "image/jpeg"
        # ★第 149 批：旧版本会把图床的**错误正文**（404/403/NoSuchKey 的
        #   HTML、Cloudflare 挑战页，500~1000 字节）当图片缓存下来，于是
        #   「地址有、海报没有」，而且修好之后旧垃圾还在顶。按图片魔数校验，
        #   不是图片就当没缓存，重新抓。
        if not _looks_like_image(data):
            return None
        return data, mime
    except Exception:
        return None


def _img_cache_write(key, data, mime):
    try:
        os.makedirs(IMG_CACHE_DIR, exist_ok=True)
        data_path, mime_path = _img_cache_paths(key)
        with open(data_path, "wb") as fp:
            fp.write(data)
        with open(mime_path, "w", encoding="utf-8") as fp:
            fp.write(mime)
    except Exception:
        pass


def _heic_to_jpeg(data):
    """HEIC/HEIF → JPEG。

    ★Windows 上的 Flutter（Skia）**不解 HEIC**，红果这类番茄系源的封面全是
    `...aifit:400:0.heic`，不转码就是一片占位块（Android 的 TVBox 能显示，
    因为系统解码器支持）。这里用 pillow + pillow-heif 转成 JPEG。
    """
    try:
        from PIL import Image
        import pillow_heif

        pillow_heif.register_heif_opener()
        img = Image.open(io.BytesIO(data))
        img = img.convert("RGB")
        img.thumbnail((720, 1080))  # 海报够用，别把 4K 图塞给界面
        out = io.BytesIO()
        img.save(out, "JPEG", quality=88)
        return out.getvalue()
    except Exception as exc:
        log_line("HEIC 转码失败：%s" % exc)
        return data


def _looks_like_image(data):
    """这段正文真的是图片吗（不看 Content-Type，只看魔数）。

    ★第 149 批：图床的**错误响应**也是「有正文、有 200」的 —— 404 / 403 /
    NoSuchKey 的 HTML、Cloudflare 挑战脚本，都是 500~1000 字节。以前一律
    当图片缓存并回给界面，表现为「源给了封面地址，界面全是占位块」。
    缓存目录里实测塞了几十份这种垃圾，只能按魔数认。
    """
    if not data or len(data) < 100:
        return False
    if data[:3] == bytes((0xFF, 0xD8, 0xFF)):          # JPEG
        return True
    if data[:8] == bytes((0x89, 0x50, 0x4E, 0x47,        # PNG
                          0x0D, 0x0A, 0x1A, 0x0A)):
        return True
    if data[:6] in (b"GIF87a", b"GIF89a"):             # GIF
        return True
    if data[:2] == b"BM":                              # BMP
        return True
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":  # WEBP
        return True
    if data[4:8] == b"ftyp":                           # HEIC / HEIF / AVIF
        return True
    return False


def fetch_image(url, referer):
    """替界面抓图：带 UA/Referer，HEIC 转 JPEG，结果落盘缓存。"""
    key = hashlib.md5((url + "|" + referer).encode("utf-8")).hexdigest()
    cached = _img_cache_read(key)
    if cached:
        return cached

    import requests

    headers = {"User-Agent": IMG_UA}
    if referer:
        headers["Referer"] = referer
    rsp = requests.get(url, headers=headers, timeout=20, verify=False)
    data = rsp.content or b""
    if not data:
        raise RuntimeError("图床返回空内容（HTTP %s）" % rsp.status_code)
    # ★第 149 批：图床的**错误响应**也是「有正文」的 —— 豆瓣防盗链回 418，
    #   正文 14 字节（`application/octet-stream`）。以前这里照样当图片回 200，
    #   界面拿到 14 字节解码失败，既显示不出海报、还白占一次「换通道重试」。
    #   现在非 2xx / 正文小到不可能是图，一律按抓取失败回 502。
    if rsp.status_code >= 400 or not _looks_like_image(data):
        raise RuntimeError("图床拒绝（HTTP %s，%d 字节）"
                           % (rsp.status_code, len(data)))
    mime = (rsp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
    is_heic = "heic" in mime or "heif" in mime or url.lower().split("?")[0].endswith(
        (".heic", ".heif")
    )
    if is_heic:
        data = _heic_to_jpeg(data)
        mime = "image/jpeg"
    if not mime.startswith("image/"):
        mime = "image/jpeg"
    _img_cache_write(key, data, mime)
    return data, mime


def log_line(text):
    try:
        sys.stdout.write(text + "\n")
        sys.stdout.flush()
    except Exception:
        pass


def brief(value, limit=60):
    s = str(value or "")
    s = s.replace("\n", " ")
    return s if len(s) <= limit else s[:limit] + "…"


DASH_DATA_PREFIX = "data:application/dash+xml;base64,"
_dash_count = 0


def _xml_unescape(text):
    for a, b in (
        ("&amp;", "&"),
        ("&lt;", "<"),
        ("&gt;", ">"),
        ("&quot;", '"'),
        ("&apos;", "'"),
    ):
        text = text.replace(a, b)
    return text


def _codec_priority(codecs):
    """照 webhtv 的 MpdEdlResolver：avc > hevc > av1 > 其它。"""
    c = (codecs or "").lower()
    if c.startswith("avc") or c.startswith("h264"):
        return 3
    if c.startswith("hev") or c.startswith("hvc"):
        return 2
    if c.startswith("av01"):
        return 1
    return 0


def _mpd_pick_streams(text):
    """从 DASH 清单里挑（最优视频流, 最高码率音频流）。

    照 webhtv 的 `MpdEdlResolver`：视频按编码优先级 → 分辨率 → 码率，
    音频取码率最高的一条。返回 (video_url, audio_url)，缺一个就是 None。
    """
    video = None
    audio = None
    for set_m in re.finditer(
        r"<AdaptationSet\b[\s\S]*?</AdaptationSet>", text, re.I
    ):
        block = set_m.group(0)
        kind = ""
        mime = re.search(r'mimeType="([^"]+)"', block, re.I)
        if mime:
            value = mime.group(1).lower()
            if value.startswith("video/"):
                kind = "video"
            elif value.startswith("audio/"):
                kind = "audio"
        for rep_m in re.finditer(
            r"<Representation\b[^>]*>[\s\S]*?</Representation>", block, re.I
        ):
            rep = rep_m.group(0)
            url_m = re.search(r"<BaseURL>([^<]+)</BaseURL>", rep, re.I)
            if not url_m:
                continue
            url = _xml_unescape(url_m.group(1)).strip()
            if not url.lower().startswith(("http://", "https://")):
                continue
            bw = 0
            bw_m = re.search(r'bandwidth="(\d+)"', rep)
            if bw_m:
                bw = int(bw_m.group(1))
            height = 0
            h_m = re.search(r'height="(\d+)"', rep)
            if h_m:
                height = int(h_m.group(1))
            codecs = ""
            c_m = re.search(r'codecs="([^"]+)"', rep, re.I)
            if c_m:
                codecs = c_m.group(1)
            if kind == "video" or (
                not kind and ('width="' in rep or 'frameRate="' in rep)
            ):
                cand = (_codec_priority(codecs), height, bw, url)
                if video is None or cand[:3] > video[:3]:
                    video = cand
            elif kind == "audio":
                if audio is None or bw > audio[2]:
                    audio = (0, 0, bw, url)
    return (
        None if video is None else video[3],
        None if audio is None else audio[3],
    )


def _edl_entry(url):
    """mpv EDL 的 `长度%串` 写法：`;` 等分隔符出现在 URL 里也安全。"""
    raw = url.encode("utf-8")
    return "%d%%%s" % (len(raw), url)


def _dash_mpd_to_edl(text):
    """DASH 清单 → mpv EDL（音视频各取直链拼一条时间线）。

    ★为什么不把清单落成 .mpd 给 mpv 的 dash 解封装：B 站 playurl 下发的
    清单里挑中的 BaseURL 常是**备份链**（签名不带 oi 等绑定参数，第 54 批
    实测取流 403），dashdec 只会闷头用那一条。webhtv 的做法是根本不喂清单
    —— 解出视频/音频直链，用 EDL 拼给 mpv，每条流各自带播放头，稳。
    """
    try:
        video, audio = _mpd_pick_streams(text)
    except Exception:
        return ""
    if not video:
        return ""
    if audio:
        return "edl://file=%s;!new_stream;file=%s" % (
            _edl_entry(video),
            _edl_entry(audio),
        )
    return "edl://file=%s" % _edl_entry(video)


def _dash_one_to_url(url):
    """一条 data:DASH 清单 → mpv EDL；解析不动再落成 .mpd 兜底。"""
    global _dash_count
    if not isinstance(url, str) or not url.startswith(DASH_DATA_PREFIX):
        return url
    try:
        raw = base64.b64decode(url[len(DASH_DATA_PREFIX):])
    except Exception:
        return url
    if not raw.startswith(b"<?xml") and b"<MPD" not in raw[:512]:
        return url
    text = raw.decode("utf-8", "replace")
    edl = _dash_mpd_to_edl(text)
    if edl:
        _dash_count += 1
        return edl
    # 兜底：清单落成本地 .mpd（mpv 自带的 ffmpeg dash 解封装接管）。
    key = hashlib.md5(raw).hexdigest()[:16]
    path = os.path.join(DASH_CACHE_DIR, key + ".mpd")
    if not os.path.exists(path):
        try:
            with open(path, "wb") as f:
                f.write(raw)
        except Exception:
            return url
    _prune_dash_cache()
    _dash_count += 1
    return "file:///" + urllib.parse.quote(path.replace("\\", "/"))


def _dash_data_to_files(url):
    """play.url 可能是串、也可能是「名字, 地址」交替数组，逐条改写。"""
    if isinstance(url, str):
        return _dash_one_to_url(url)
    if isinstance(url, list):
        return [_dash_one_to_url(x) if isinstance(x, str) else x for x in url]
    return url


def _prune_dash_cache(keep=32):
    """清单文件很小，但也别无限攒：超过 keep 个按修改时间删最旧的。"""
    try:
        entries = []
        for name in os.listdir(DASH_CACHE_DIR):
            path = os.path.join(DASH_CACHE_DIR, name)
            if os.path.isfile(path):
                entries.append((os.path.getmtime(path), path))
        if len(entries) <= keep:
            return
        entries.sort()
        for _, path in entries[: len(entries) - keep]:
            try:
                os.remove(path)
            except Exception:
                pass
    except Exception:
        pass


def call_action(key, action, body):
    spider = get_spider(key, body.get("extend"))
    started = time.time()
    with get_lock(key):
        if action == "init":
            # ★jar 站点借 init 做冷启动（第 146 批）：dex2jar 转换 + 起 JVM
            #   实测 98 秒，压在第一次 home 里会被 App 的 45 秒超时掐掉，
            #   表现成「一直加载 → 拉取失败」。init 的客户端超时放宽到 4 分钟。
            #
            # ★第 147 批：把守卫结论一起回给 App。以前 init 只会 `{"ok":true}`，
            #   App 看到「桥起来了」就当加载成功 —— 于是主页刷出 97 个站点，
            #   点进去全是「宿主校验未通过」。现在 App 拿 hostAdmission 决定
            #   要不要报成功。
            warm = getattr(spider, "warm", None)
            if warm is not None:
                try:
                    state = warm()
                except Exception as exc:  # 预热失败不影响后续调用
                    sys.stderr.write("[bridge] 预热失败（%s）：%s\n" % (key, exc))
                    state = "error"
                return {"ok": True, "hostAdmission": str(state or "")}
            return {"ok": True}
        if action == "home":
            data = norm_home(call_spider(spider.homeContent, True))
            try:
                extra = call_spider(spider.homeVideoContent)
            except Exception:
                extra = None
            if isinstance(extra, dict):
                if extra.get("list"):
                    data["list"] = extra["list"]
                if extra.get("class"):
                    data["class"] = extra["class"]
            # 有些源（红果短剧、哔哩直播…）的 homeContent 只给分类不给推荐位，
            # 首页就会空一片。拿第一个分类的第一页顶上，省用户先点分类。
            if not data.get("list") and data.get("class"):
                try:
                    first = data["class"][0]
                    tid = str(first.get("type_id") or first.get("id") or "")
                    if tid:
                        page = call_spider(
                            spider.categoryContent, tid, "1", True, {}
                        )
                        if isinstance(page, dict) and page.get("list"):
                            data["list"] = page["list"]
                except Exception:
                    pass
            log_line(
                "[%s] home → %d 条 / %d 类 %.0fms"
                % (key, len(data.get("list") or []), len(data.get("class") or []),
                   (time.time() - started) * 1000)
            )
            return data
        if action == "category":
            tid = str(body.get("id", ""))
            page = str(body.get("page", 1))
            filters = body.get("filters") or {}
            # ★tid 为空只可能是传输层丢参数（见 CatpawClient 的 contentLength 注释）。
            # 以前这种请求会被当成「全部分类」，让每个分类都返回同一批数据。
            if not tid:
                log_line("[%s] category 缺 tid，已忽略" % key)
                return norm_page({"list": []}, 1)
            data = call_spider(spider.categoryContent, tid, page, True, filters)
            out = norm_page(data, int(page) if page.isdigit() else 1)
            log_line(
                "[%s] category tid=%s pg=%s → %d 条 %.0fms"
                % (key, tid, page, len(out.get("list") or []),
                   (time.time() - started) * 1000)
            )
            return out
        if action == "detail":
            ids = body.get("ids")
            if not ids:
                one = body.get("id")
                ids = [one] if one else []
            ids = [str(x) for x in as_list(ids) if str(x).strip()]
            if not ids:
                log_line("[%s] detail 缺 id，已忽略" % key)
                return {"list": []}
            data = call_spider(spider.detailContent, ids)
            out = data if isinstance(data, dict) else {"list": []}
            first = (out.get("list") or [{}])[0] if out.get("list") else {}
            log_line(
                "[%s] detail id=%s → %d 条 from=%s %.0fms"
                % (
                    key,
                    brief(ids[0], 48),
                    len(out.get("list") or []),
                    brief(first.get("vod_play_from"), 24),
                    (time.time() - started) * 1000,
                )
            )
            return out
        if action == "search":
            wd = str(body.get("wd", ""))
            page = str(body.get("page", 1))
            quick = bool(body.get("quick", False))
            if not wd.strip():
                log_line("[%s] search 缺关键词，已忽略" % key)
                return norm_page({"list": []}, 1)
            data = call_spider(spider.searchContent, wd, quick, page)
            out = norm_page(data, int(page) if page.isdigit() else 1)
            log_line(
                "[%s] search wd=%s pg=%s → %d 条 %.0fms"
                % (key, brief(wd, 24), page, len(out.get("list") or []),
                   (time.time() - started) * 1000)
            )
            return out
        if action == "play":
            flag = str(body.get("flag", ""))
            play_id = str(body.get("id", ""))
            vip = body.get("vipFlags") or []
            if not play_id:
                log_line("[%s] play 缺 id，已忽略" % key)
                return {"parse": 0, "url": ""}
            data = call_spider(spider.playerContent, flag, play_id, vip)
            out = data if isinstance(data, dict) else {"parse": 0, "url": ""}
            # parse 归一成数字：源常写 `"1"` 字符串，Dart 侧强转曾经会炸。
            out["parse"] = as_int(out.get("parse"), 0)
            # ★数组 / 对象原样透传（第 48 批）：`str()` 会把
            # `["无损FLAC", "http://…flac?bitrate$2000", "高品质320K", "http://…"]`
            # 拼成一串 Python repr，Dart 侧 `parsePlayUrls` 当它是**一个地址**，
            # `looksPlayableUrl` 见首字符是 `[` 就报「站源返回的播放地址无效」。
            # 酷我音乐（多档位音乐源）正是这个形态；红果短剧那类也是。
            raw_url = out.get("url")
            if not isinstance(raw_url, (list, dict)):
                out["url"] = str(raw_url or "")
            # parse 非 0 = 源自己也不给真地址，要「网页解析」；抓页面挖 m3u8。
            # B 站把音视频分离的 DASH 清单 base64 成 data: URI 塞进 url。
            # Dart 侧只认 file/http 等 scheme（严格白名单，防 Python repr 之类
            # 垃圾串混进来），data: 会被判「未取到播放地址」。统一在桥里落成
            # 本地 .mpd，给 file:// 地址 —— mpv 的 ffmpeg dash 解封装照常接管。
            # B 站风控下发的取流 URL 带 buvid 绑定，取流时不带同一枚
            # buvid3 Cookie 就回 403（第 54 批实测）。把 spider 会话里的
            # Cookie 并进播放头，mpv 对所有请求（含 DASH 分段）都会带上。
            try:
                hdr = out.get("header")
                if isinstance(hdr, dict):
                    merged = _merge_cookie(
                        hdr.get("Cookie") or "", _spider_cookie(spider)
                    )
                    if merged:
                        hdr["Cookie"] = merged
            except Exception:
                pass
            before = out["url"]
            out["url"] = _dash_data_to_files(out["url"])
            if out["url"] != before:
                log_line("[%s] play data:DASH → file://%d 处" % (key, _dash_count))
            if out["parse"] != 0:
                out = resolve_web_play(spider, out, play_id)
            log_line(
                "[%s] play flag=%s id=%s → parse=%s url=%s"
                % (key, brief(flag, 16), brief(play_id, 40),
                   out.get("parse"), brief(out.get("url"), 70))
            )
            return out
        if action == "proxy":
            return spider.localProxy(body.get("param") or {})
        if action == "live":
            # py 直播接口（第 155 批）：TVBox `type:3` + `api` 指向 .py 的源，
            # 频道表由 spider.liveContent(url) 出（一段 m3u 文本，台址全是
            # `…/proxy?…` 的代理地址），取流走 GET /site/<key>/proxy。
            # liveContent 在老的 base.spider 兜底里也有（返回空串），所以
            # getattr 拿不到就当「源没实现」，别让整个请求 500。
            url = body.get("url") or ""
            fn = getattr(spider, "liveContent", None)
            if fn is None:
                return {"ok": False, "text": "", "error": "源没有 liveContent"}
            try:
                out = fn(url)
            except TypeError:
                out = fn()
            if isinstance(out, (list, tuple)):
                out = out[0] if out else ""
            return {"ok": True, "text": out if isinstance(out, str) else str(out)}
        if action == "action":
            # ★源内动作（第 162 批）：对齐 TVBox / 蜂蜜的 ActionCardHelper。
            # 「设置中心 / 文件浏览」那类条目（`vod_tag:action` 或原生
            # `action` 字段）点开时不进详情、不搜索，把动作卡原文交给源
            # 自己的 `spider.action` 执行，按返回的 type / msg / list 分发。
            # py 源的 base.spider 有同名空桩（返回 None）→ 回 ok:false，
            # App 侧落回「需要源客户端」的说明，不会假装执行成功。
            raw = str(body.get("action") or body.get("id") or "")
            vid = str(body.get("vid") or "")
            if not raw.strip():
                return {"ok": False, "error": "缺动作参数"}
            fn = getattr(spider, "action", None)
            if fn is None:
                return {"ok": False, "error": "源不支持动作执行"}
            # ★★第 184 批：**「双击才生效」的动作必须在一次请求里连按两下**。
            # 潇洒的清除 Cookie / 清除 Token / 重置配置写的是
            #   `if (now - lastResetClickTime < 500) 真执行; else 记时间`
            # ——防误触。App 以前是「发两笔 action 请求、间隔 150ms」，可下面
            # 这条 wait_ui_events 要阻塞最多 4 秒才回响应，等第二笔到 JVM 时
            # 早就过了 500ms，源于是永远「只记时间不执行」（用户看到的就是
            # 「点了没反应」）。现在 repeat/gap 由桥自己控制节奏。
            try:
                repeat = int(body.get("repeat") or 1)
            except (TypeError, ValueError):
                repeat = 1
            repeat = max(1, min(3, repeat))
            try:
                gap = float(body.get("gap") or 0.12)
            except (TypeError, ValueError):
                gap = 0.12
            gap = max(0.02, min(0.45, gap))
            mark = UI_EVENT_SEQ[0]
            out = None
            for i in range(repeat):
                if i:
                    time.sleep(gap)
                try:
                    res = call_spider(fn, raw, vid)
                except TypeError:
                    res = call_spider(fn, raw)
                if res is not None and not (isinstance(res, str) and not res.strip()):
                    out = res
            if out is None or (isinstance(out, str) and not out.strip()) or (
                isinstance(out, dict) and not out
            ):
                # ★空返回不一定是失败（第 163 批）：Fish/Config 这批源的
                # action 是「发射后不管」——真正的弹窗（扫码 / 提示）在另一条
                # 线程里经 JVM 桩上报到 /hook/ui。等最多 4 秒把事件捎回去；
                # 真的什么都没有才回 ok:false。
                events = wait_ui_events(mark)
                if events:
                    return {"ok": True, "ui": events, "seq": UI_EVENT_SEQ[0]}
                # ★第 165 批：`seq` 一并回去 —— App 拿它当续拉游标的起点，
                # 源的轮询线程几十秒后才冒出来的「授权成功」也能收到。
                return {
                    "ok": False,
                    "error": "源没有返回执行结果",
                    "seq": UI_EVENT_SEQ[0],
                }
            if isinstance(out, dict):
                events, seq = ui_events_since(mark)
                if events:
                    out.setdefault("ui", events)
                out.setdefault("seq", seq)
                return out
            # 一段非 JSON 文本：原样带给 App 当提示。
            return {"ok": True, "text": str(out)}
    raise RuntimeError("未知动作：" + action)


def wait_ui_events(mark, timeout=4.0):
    """等 JVM 桩上报的 UI 事件到齐（第 163 批）。

    源的 action 是异步弹窗：`spider.action(...)` 立刻返回空串，真正的
    窗在另一条线程里 POST /hook/ui。这里在原地等最多 `timeout` 秒，
    收到新事件就提前返回（让 App 尽快弹）。没有任何事件回空列表。

    ★第 165 批：`mark` 从「列表长度」改成**事件序号**。旧写法在
    `push_ui_event` 截断列表（>16 条丢老的）之后会错位，一次长轮询
    （百度扫码那种要等几十秒的）攒满事件后 mark 就失效了。
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        with UI_EVENTS_LOCK:
            newer = [e for e in UI_EVENTS if int(e.get("seq") or 0) > mark]
        if newer:
            return newer
        time.sleep(0.08)
    return []


def ui_events_since(since):
    """取序号大于 `since` 的事件（第 165 批的 `POST /ui/poll` 用）。"""
    with UI_EVENTS_LOCK:
        events = [e for e in UI_EVENTS if int(e.get("seq") or 0) > since]
        return events, UI_EVENT_SEQ[0]


def push_ui_event(body):
    """收一条桩上报（带锁截断），顺手打上自增序号。"""
    with UI_EVENTS_LOCK:
        UI_EVENT_SEQ[0] += 1
        if isinstance(body, dict):
            body["seq"] = UI_EVENT_SEQ[0]
        UI_EVENTS.append(body)
        if len(UI_EVENTS) > UI_EVENTS_MAX:
            del UI_EVENTS[:-UI_EVENTS_MAX]


## 上一次「把各站点凭证收进池子」的时刻（`/pan/state` 每 2 秒会被问一次）。
_PAN_IMPORT_AT = [0.0]


def pan_login_state(site_key):
    """各标准盘的登录状态（第 189 批）。

    先让账号池把各站点 `ext/TVBox` 里**源刚写下的**凭证收进来 —— 扫码成功
    那一刻就是源写文件的那一刻，池子不收就永远看不出「已经登上了」。这步
    只读几个目录列表，1.5 秒内重复请求直接跳过。
    """
    out = {"ok": True, "accounts": {}}
    key = str(site_key or "")
    if not key.startswith("jar_"):
        return out
    try:
        import jarsite

        if time.time() - _PAN_IMPORT_AT[0] > 1.5:
            _PAN_IMPORT_AT[0] = time.time()
            jarsite.pan_vault_import(SITES_DIR)
    except Exception:
        pass
    try:
        spider = get_spider(key)
        state = spider.pan_state() if hasattr(spider, "pan_state") else {}
    except Exception as exc:
        out["error"] = str(exc)
        return out
    if isinstance(state, dict):
        out["accounts"] = state
    return out


def pan_login_scan(site_key, brand):
    """代按一次扫码（第 189 批）：具体找哪个站点、按什么动作由 jarsite 定。

    动作值本身基本是空串（源把窗画在自己的 Dialog 里），所以「成没成」看
    事件 —— `wait_ui_events` 把这次动作期间冒出来的窗一起捎回 App。
    """
    key = str(site_key or "")
    brand = str(brand or "").strip()
    if not key.startswith("jar_"):
        return {"ok": False, "msg": "这个源没有扫码登录入口。"}
    if not brand:
        return {"ok": False, "msg": "没认出是哪个网盘。"}
    try:
        spider = get_spider(key)
    except Exception as exc:
        return {"ok": False, "msg": str(exc)}
    if not hasattr(spider, "pan_scan"):
        return {"ok": False, "msg": "这个源没有扫码登录入口。"}
    mark = UI_EVENT_SEQ[0]
    try:
        res = spider.pan_scan(brand)
    except Exception as exc:
        sys.stderr.write("[pan] 扫码失败（%s/%s）：%s\n" % (key, brand, exc))
        return {"ok": False, "msg": str(exc) or exc.__class__.__name__}
    if not isinstance(res, dict):
        res = {"ok": True}
    events = wait_ui_events(mark, 6.0)
    if events:
        res.setdefault("ui", events)
    res["seq"] = UI_EVENT_SEQ[0]
    res.setdefault("ok", True)
    log_line("[pan] %s 扫码 %s → %s（%d 条窗事件）" % (
        key, brand, res.get("action") or res.get("msg") or "?", len(events)))
    return res



# ---- 多源歌词：打分、抓取、任务调度 ---------------------------------------
# 打分规则照抄 webhtv 的 `LyricsMatcher`（见参考工程 player/lyrics）：
# 歌名 72/46/-72、歌手 28/14/-12、时长 24/20/14/4/-18/-40，再按「合集/歌单/
# 排行榜」这类标题扣分。分数只用来排序，界面拿到的 `score` 就是它。


def _lyric_norm(text):
    """歌名归一：全半角、括号注释、后缀词、标点全去掉，只留文字数字。"""
    value = (text or "").strip().lower()
    if not value:
        return ""
    value = unicodedata.normalize("NFKC", value)
    value = re.sub(r"\.[a-z0-9]{2,5}$", "", value)
    value = re.sub(r"\([^)]*\)|\[[^]]*\]|（[^）]*）|【[^】]*】", "", value)
    value = re.sub(
        r"official|music video|video|audio|lyrics|lyric|flac|mp3|lossless|"
        r"tv size|feat\.?|featuring|\bmv\b",
        "",
        value,
        flags=re.IGNORECASE,
    )
    value = re.sub(
        r"(?:live|cover|remix|instrumental|karaoke)(?: version| ver\.?|版)?$",
        "",
        value,
        flags=re.IGNORECASE,
    )
    value = re.sub(r"(?:现场版|翻唱版|伴奏版|纯音乐版|原唱版)$", "", value)
    value = re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", value)
    return value.strip()


def _lyric_text_score(wanted, actual, exact, related, mismatch):
    a = _lyric_norm(wanted)
    b = _lyric_norm(actual)
    if not a:
        return 0
    if not b:
        return mismatch // 2
    if a == b:
        return exact
    if a not in b and b not in a:
        # 「海阔天空 Beyond」这种把歌手缀在歌名后面的写法：候选名是前缀/后缀、
        # 剩下那截是拉丁字母（歌手名）就算「相关」，别一棍子打成不匹配。
        rest = ""
        if a.startswith(b):
            rest = a[len(b) :]
        elif a.endswith(b):
            rest = a[: len(a) - len(b)]
        if rest and len(rest) <= 14 and rest.isascii():
            return related
        return mismatch
    if len(a) <= 1 or len(b) <= 1:
        return mismatch
    ratio = min(len(a), len(b)) / float(max(len(a), len(b)))
    if ratio >= 0.75:
        return related
    if ratio >= 0.55:
        return max(18, related - 14)
    return mismatch // 2


def _lyric_duration_score(wanted_ms, actual_ms):
    if wanted_ms <= 0 or actual_ms <= 0:
        return 0
    delta = abs(wanted_ms - actual_ms) / 1000.0
    if delta <= 2:
        return 24
    if delta <= 5:
        return 20
    if delta <= 10:
        return 14
    if delta <= 20:
        return 4
    if delta <= 40:
        return -18
    return -40


def _lyric_pair_score(job, cand, title, artist):
    """按一组（歌名, 歌手）算一首候选的分数。"""
    dur = job["dur"]
    name = cand.get("name") or ""
    title_score = _lyric_text_score(title, name, 72, 46, -72)
    time_score = _lyric_duration_score(dur, cand.get("duration") or 0)
    score = title_score + time_score
    if artist:
        score += _lyric_text_score(artist, cand.get("artist"), 28, 14, -12)
    norm = _lyric_norm(name)
    for word in ("合集", "歌单", "盘点", "排行榜", "热歌榜", "频道", "最好听", "宝藏"):
        if word in norm:
            score -= 70
            break
    if len(norm) > 36:
        score -= 36
    elif len(norm) > 28:
        score -= 20
    if title_score >= 72 and time_score >= 20:
        score += 8
    return score


def _lyric_song_score(job, cand):
    """取「整串当歌名」与「拆出歌手」两种解释里更高的那一个。

    ★为什么不是只拆一种：`_playTitle` 是站源给的集名，写法五花八门 ——
    `光辉岁月 - Beyond`、`海阔天空 Beyond`、`Hotel California`、
    `晴天 周杰伦` 都有。按空格硬拆会把英文歌名拆坏，不拆又把中文的
    「歌名 歌手」当成一整个歌名（于是全部候选都被判不匹配）。所以两种
    解释都算一遍，谁像就用谁。
    """
    best = None
    pairs = job.get("pairs") or [(job.get("title") or "", job.get("artist") or "")]
    for title, artist in pairs:
        score = _lyric_pair_score(job, cand, title, artist)
        if best is None or score > best:
            best = score
    return best if best is not None else 0


def _lyric_pairs(keyword, artist):
    """把用户/界面给的串拆成若干种（歌名, 歌手）解释，去重保序。"""
    pairs = []
    parts = re.split(r"\s*[-—|｜·]\s*", keyword, maxsplit=1)
    if len(parts) == 2 and parts[0].strip() and parts[1].strip():
        pairs.append((parts[0].strip(), parts[1].strip()))
    space = re.match(r"^(.*\S)\s+(\S.{0,24})$", keyword)
    if space and space.group(1).strip():
        pairs.append((space.group(1).strip(), space.group(2).strip()))
    if artist.strip():
        pairs.append((keyword.strip(), artist.strip()))
    pairs.append((keyword.strip(), ""))
    out = []
    for pair in pairs:
        if pair not in out:
            out.append(pair)
    return out


def _lyric_http(url, params=None, referer=""):
    import requests

    headers = {"User-Agent": LYRIC_UA}
    if referer:
        headers["Referer"] = referer
    return requests.get(
        url, params=params, headers=headers, timeout=8, verify=False
    )


def _lyric_json(text):
    """解析 JSON / JSONP：QQ 有些接口会套一层 `callback({...})`。"""
    body = (text or "").strip()
    if not body:
        return {}
    start = body.find("{")
    end = body.rfind("}")
    if start < 0 or end <= start:
        return {}
    try:
        return json.loads(body[start : end + 1])
    except Exception:
        return {}


def _lyric_src_netease(job):
    rsp = _lyric_http(
        "https://music.163.com/api/search/get/web",
        {"s": job["query"], "type": 1, "limit": 8},
        "https://music.163.com/",
    )
    songs = ((rsp.json() or {}).get("result") or {}).get("songs") or []
    out = []
    for song in songs:
        artists = "/".join(
            a.get("name", "") for a in (song.get("artists") or []) if a.get("name")
        )
        out.append(
            {
                "id": "netease:%s" % song.get("id"),
                "name": song.get("name") or "",
                "artist": artists,
                "album": (song.get("album") or {}).get("name") or "",
                # 网易给的 duration 是毫秒
                "duration": int(song.get("duration") or 0),
                # yrc（逐字）现在大多要登录才给，命中列表里不夸口。
                "word": None,
            }
        )
    return out


def _lyric_src_qq(job):
    rsp = _lyric_http(
        "https://c.y.qq.com/soso/fcgi-bin/client_search_cp",
        {
            "format": "json",
            "inCharset": "utf8",
            "outCharset": "utf-8",
            "notice": "0",
            "platform": "yqq",
            "needNewCode": "0",
            "w": job["query"],
            "p": "1",
            "n": "8",
            "cr": "1",
        },
        "https://y.qq.com/",
    )
    data = _lyric_json(rsp.text)
    songs = ((data.get("data") or {}).get("song") or {}).get("list") or []
    out = []
    for item in songs:
        mid = item.get("songmid") or item.get("mid") or ""
        if not mid:
            continue
        artists = "/".join(
            s.get("name", "") for s in (item.get("singer") or []) if s.get("name")
        )
        out.append(
            {
                "id": "qq:%s" % mid,
                "name": item.get("songname") or item.get("name") or "",
                "artist": artists,
                "album": item.get("albumname") or "",
                # interval 是秒
                "duration": int(item.get("interval") or 0) * 1000,
            }
        )
    return out


def _lyric_src_kugou(job):
    rsp = _lyric_http(
        "http://mobilecdn.kugou.com/api/v3/search/song",
        {
            "format": "json",
            "keyword": job["query"],
            "page": "1",
            "pagesize": "8",
            "api_ver": "1",
            "area_code": "1",
            "correct": "1",
            "plat": "2",
            "tag": "1",
            "sver": "5",
            "showtype": "10",
            "version": "8990",
        },
    )
    info = ((rsp.json() or {}).get("data") or {}).get("info") or []
    out = []
    for item in info:
        hash_ = item.get("hash") or ""
        if not hash_:
            continue
        name = item.get("songname") or ""
        artist = item.get("singername") or ""
        out.append(
            {
                "id": "kugou:%s" % hash_,
                "name": name,
                "artist": artist,
                "album": item.get("album_name") or "",
                "duration": int(item.get("duration") or 0) * 1000,
                # 取词时要用「歌名 - 歌手」当关键词
                "keyword": ("%s - %s" % (name, artist)).strip(" -"),
                # 酷狗有 KRC（逐字），拿不到时回退 lrc。
                "word": True,
            }
        )
    return out


def _lyric_src_kuwo(job):
    rsp = _lyric_http(
        "https://search.kuwo.cn/r.s",
        {
            "all": job["query"],
            "ft": "music",
            "newsearch": "1",
            "itemset": "web_2013",
            "client": "kt",
            "pn": "0",
            "rn": "8",
            "rformat": "json",
            "encoding": "utf8",
        },
        "https://www.kuwo.cn/",
    )
    # ★酷我返回的是单引号「伪 JSON」，json.loads 不认，只能用 literal_eval。
    try:
        data = ast.literal_eval(rsp.text)
    except Exception:
        return []
    out = []
    for item in data.get("abslist") or []:
        rid = str(item.get("DC_TARGETID") or item.get("MUSICRID") or "")
        rid = rid.replace("MUSIC_", "").strip()
        if not rid:
            continue
        try:
            seconds = float(item.get("DURATION") or 0)
        except (TypeError, ValueError):
            seconds = 0.0
        out.append(
            {
                "id": "kuwo:%s" % rid,
                "name": item.get("SONGNAME") or item.get("NAME") or "",
                "artist": item.get("ARTIST") or item.get("AARTIST") or "",
                "album": item.get("ALBUM") or "",
                "duration": int(seconds * 1000),
                # 酷我 mobi 的 lrcx 自带字级时间（逐字）。
                "word": True,
            }
        )
    return out


def _lyric_src_lrclib(job):
    rsp = _lyric_http(
        "https://lrclib.net/api/search",
        {"q": job["query"]},
        "",
    )
    if rsp.status_code != 200:
        return []
    try:
        items = rsp.json()
    except Exception:
        return []
    if not isinstance(items, list):
        return []
    out = []
    for item in items[:8]:
        try:
            seconds = float(item.get("duration") or 0)
        except (TypeError, ValueError):
            seconds = 0.0
        out.append(
            {
                "id": "lrclib:%s" % item.get("id"),
                "name": item.get("trackName") or item.get("name") or "",
                "artist": item.get("artistName") or "",
                "album": item.get("albumName") or "",
                "duration": int(seconds * 1000),
            }
        )
    return out


def _lyric_source_table():
    return (
        ("netease", "网易云", _lyric_src_netease),
        ("qq", "QQ音乐", _lyric_src_qq),
        ("kugou", "酷狗", _lyric_src_kugou),
        ("kuwo", "酷我", _lyric_src_kuwo),
        ("lrclib", "LRCLIB", _lyric_src_lrclib),
    )


def _lyric_prune_jobs():
    """锁内调用：清过期任务，超出上限的按时间从旧到新丢。"""
    now = time.time()
    for token in [t for t, j in LYRIC_JOBS.items() if now - j["ts"] > LYRIC_JOB_TTL]:
        LYRIC_JOBS.pop(token, None)
    if len(LYRIC_JOBS) > LYRIC_JOB_MAX:
        ordered = sorted(LYRIC_JOBS.items(), key=lambda kv: kv[1]["ts"])
        for token, _job in ordered[: len(LYRIC_JOBS) - LYRIC_JOB_MAX]:
            LYRIC_JOBS.pop(token, None)


def _lyric_run_source(job, key, label, fetch):
    items = []
    state = "ok"
    try:
        items = fetch(job) or []
    except Exception as exc:
        state = "err"
        log_line("歌词源 %s 失败：%s" % (label, brief(exc, 80)))
    if state == "ok" and not items:
        state = "empty"
    for cand in items:
        cand["source"] = key
        cand["sourceLabel"] = label
        cand["score"] = _lyric_song_score(job, cand)
    with LYRIC_JOBS_LOCK:
        job["results"].extend(items)
        job["sources"][key] = {
            "key": key,
            "label": label,
            "state": state,
            "count": len(items),
        }
        job["pending"].discard(key)
        if not job["pending"]:
            job["done"] = True
        for cand in items:
            if len(LYRIC_META) > LYRIC_META_MAX:
                LYRIC_META.clear()
            LYRIC_META[cand["id"]] = cand


def _lyric_start_job(keyword, pairs, duration_ms):
    query = keyword.strip()
    title, artist = pairs[0] if pairs else (query, "")
    job = {
        "token": "%x%s" % (int(time.time() * 1000), os.urandom(3).hex()),
        "title": title,
        "artist": artist,
        # 两种（歌名, 歌手）解释都带着，打分时取更像的那一种
        "pairs": pairs,
        "dur": duration_ms,
        "query": query,
        "results": [],
        "sources": {},
        "pending": set(),
        "done": False,
        "ts": time.time(),
    }
    table = _lyric_source_table()
    job["pending"] = {key for key, _label, _fetch in table}
    for key, label, _fetch in table:
        job["sources"][key] = {
            "key": key,
            "label": label,
            "state": "run",
            "count": 0,
        }
    with LYRIC_JOBS_LOCK:
        _lyric_prune_jobs()
        LYRIC_JOBS[job["token"]] = job
    for key, label, fetch in table:
        threading.Thread(
            target=_lyric_run_source,
            args=(job, key, label, fetch),
            daemon=True,
        ).start()
    return job


def _lyric_snapshot(job):
    with LYRIC_JOBS_LOCK:
        items = list(job["results"])
        sources = [job["sources"][key] for key in sorted(job["sources"])]
        done = job["done"]
    items.sort(key=lambda it: it.get("score") or 0, reverse=True)
    hits = []
    seen = set()
    for item in items:
        if (item.get("score") or 0) < 0:
            continue
        # 同源同曲只留一条（不同源各留一条：有的源给逐行、有的给逐字）。
        key = (
            item.get("source"),
            _lyric_norm(item.get("name")),
            _lyric_norm(item.get("artist")),
        )
        if key in seen:
            continue
        seen.add(key)
        hits.append(
            {
                "id": item.get("id"),
                "name": item.get("name") or "",
                "artist": item.get("artist") or "",
                "album": item.get("album") or "",
                "duration": int(item.get("duration") or 0),
                "source": item.get("source"),
                "sourceLabel": item.get("sourceLabel") or "",
                "score": int(item.get("score") or 0),
                # 该源能不能给逐字歌词（界面上的「逐字 / 逐句」角标）：
                # True 逐字、False 逐句、None 不好说（不显示角标）。
                "word": item.get("word"),
            }
        )
        if len(hits) >= 24:
            break
    return {"token": job["token"], "done": done, "sources": sources, "list": hits}


# ---------------------------------------------------------------- 逐字歌词
#
# 参考 webhtv 的 LyricsParser / QqMusicClient / KugouClient / NeteaseClient：
# 「逐字」在选词阶段是各家的私有格式（网易 yrc、酷狗 krc、QQ qrc），到界面
# 之前统一转成**增强 LRC**：
#
#     [mm:ss.xx]<起始偏移ms,时长ms>字<起始偏移ms,时长ms>字…
#
# 偏移是**相对本行起点**的毫秒（webhtv 的 LyricsWord 就叫 startOffsetMs）。
# Dart 侧的 `core/lyrics.dart` 只认这一种形状，哪家源的私有格式都在桥里化掉。

_LYRIC_EAPI_KEY = b"e82ckenh8dichen8"
_YRC_LINE = re.compile(r"^\[(\d+),(\d+)\](.*)$")
_YRC_WORD = re.compile(r"\((\d+),(\d+),\d+\)([^()]*)")
# ★16 字节（末尾 0x69 别漏）：webhtv 的 KRC_KEY 少了最后一个字节，照着抄
# 会「zlib 头对、数据全错」—— 这是这批踩到的坑。
_KRC_KEY = bytes(
    [
        0x40, 0x47, 0x61, 0x77, 0x5E, 0x32, 0x74, 0x47,
        0x51, 0x36, 0x31, 0x2D, 0xCE, 0xD2, 0x6E, 0x69,
    ]
)
_KRC_LINE = re.compile(r"^\[(-?\d+),(-?\d+)\](.*)$")
_KRC_WORD = re.compile(r"<(-?\d+),(-?\d+),-?\d+>([^<]*)")


def _enhanced_time(ms):
    """毫秒 → 增强 LRC 的时间标签 `[mm:ss.xx]`。"""
    value = max(0, int(ms))
    return "[%02d:%05.2f]" % (value // 60000, (value % 60000) / 1000.0)


def _word_lrc(line_start, body):
    """把 `(起点,时长,?)字` / `<起点,时长,?>` 两种词标记拼成增强 LRC 的一行。"""
    words = []
    for match in body:
        raw_start = int(match[0])
        # 有的源给绝对毫秒、有的给相对偏移：明显超出本行起点就减掉。
        start = raw_start - line_start if line_start > 2000 and raw_start >= line_start else raw_start
        text = match[1]
        if not text:
            continue
        words.append("<%d,%d>%s" % (max(0, start), max(0, int(match[2])), text))
    return "".join(words)


def _yrc_to_enhanced(yrc):
    """网易 yrc：`[行起点,行时长](词起点,词时长,0)字…` → 增强 LRC。"""
    out = []
    for raw in (yrc or "").replace("\r", "").split("\n"):
        line = raw.strip()
        head = _YRC_LINE.match(line)
        if not head:
            continue
        start = int(head.group(1))
        words = _word_lrc(
            start,
            (
                (m.group(1), m.group(3), m.group(2))
                for m in _YRC_WORD.finditer(head.group(3))
            ),
        )
        if words:
            out.append(_enhanced_time(start) + words)
    return "\n".join(out)


def _krc_decode(content):
    """酷狗 krc：base64 → 去 `krc1` 头 → 逐字节异或 → zlib 解压。"""
    import zlib

    raw = base64.b64decode(content)
    if raw[:4] == b"krc1":
        raw = raw[4:]
    data = bytes(b ^ _KRC_KEY[i % len(_KRC_KEY)] for i, b in enumerate(raw))
    try:
        return zlib.decompress(data).decode("utf-8", "ignore")
    except Exception:
        return zlib.decompress(data, -15).decode("utf-8", "ignore")


def _krc_to_enhanced(krc):
    """酷狗 krc：`[行起点,行时长]<词偏移,词时长,0>字…` （偏移本来就是相对的）。"""
    out = []
    for raw in (krc or "").replace("\r", "").split("\n"):
        line = raw.strip()
        head = _KRC_LINE.match(line)
        if not head:
            continue
        start = int(head.group(1))
        if start < 0:
            continue
        body = head.group(3)
        words = []
        for m in _KRC_WORD.finditer(body):
            if not m.group(3):
                continue
            words.append(
                "<%d,%d>%s" % (max(0, int(m.group(1))), max(0, int(m.group(2))), m.group(3))
            )
        if words:
            out.append(_enhanced_time(start) + "".join(words))
    return "\n".join(out)


def _lyric_eapi(path, payload):
    """网易 eapi 的签名参数（AES-128-ECB，key 是客户端公开常量）。"""
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad

    text = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    digest = hashlib.md5(
        ("nobody%suse%smd5forencrypt" % (path, text)).encode("utf-8")
    ).hexdigest()
    plain = ("%s-36cd479b6b5-%s-36cd479b6b5-%s" % (path, text, digest)).encode("utf-8")
    return AES.new(_LYRIC_EAPI_KEY, AES.MODE_ECB).encrypt(pad(plain, 16)).hex().upper()


def _lyric_post(url, body, referer=""):
    import requests

    headers = {
        "User-Agent": LYRIC_UA,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    if referer:
        headers["Referer"] = referer
    return requests.post(url, data=body, headers=headers, timeout=8, verify=False)


def _lyric_fetch_netease(song_id):
    """网易：先试 eapi 的 yrc（逐字），没有就退回老接口的 lrc（逐句）。"""
    try:
        path = "/api/song/lyric/v1"
        # ★注意这些开关是「0 = 需要、-1 = 不要」（webhtv 也是全传 0）。
        params = _lyric_eapi(
            path,
            {
                "id": int(song_id),
                "cp": False,
                "tv": 0,
                "lv": 0,
                "rv": 0,
                "kv": 0,
                "yv": 0,
                "ytv": 0,
                "yrv": 0,
            },
        )
        rsp = _lyric_post(
            "https://interface.music.163.com" + path,
            ("params=" + params).encode("utf-8"),
            "https://music.163.com/",
        )
        data = rsp.json() or {}
        yrc = ((data.get("yrc") or {}).get("lyric") or "").strip()
        if yrc:
            text = _yrc_to_enhanced(yrc)
            if text.strip():
                return text
        lrc = ((data.get("lrc") or {}).get("lyric") or "").strip()
        if lrc:
            return lrc
    except Exception:
        pass
    rsp = _lyric_http(
        "https://music.163.com/api/song/lyric",
        {"id": song_id, "lv": 1, "kv": 1, "tv": -1},
        "https://music.163.com/",
    )
    return ((rsp.json() or {}).get("lrc") or {}).get("lyric") or ""


def _lyric_fetch_qq(song_mid):
    rsp = _lyric_http(
        "https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg",
        {
            "format": "json",
            "inCharset": "utf8",
            "outCharset": "utf-8",
            "notice": "0",
            "platform": "yqq",
            "needNewCode": "0",
            # nobase64=1：直接给 LRC 原文，省得再解一层 base64
            "nobase64": "1",
            "songmid": song_mid,
            "songtype": "0",
            "loginUin": "0",
            "hostUin": "0",
            "g_tk": "5381",
        },
        "https://y.qq.com/portal/player.html",
    )
    data = _lyric_json(rsp.text)
    return data.get("lyric") or ""


def _lyric_fetch_kugou(hash_):
    meta = LYRIC_META.get("kugou:" + hash_) or {}
    keyword = meta.get("keyword") or ""
    if not keyword:
        keyword = ("%s - %s" % (meta.get("name") or "", meta.get("artist") or "")).strip(
            " -"
        )
    if not keyword:
        return ""
    rsp = _lyric_http(
        "http://lyrics.kugou.com/search",
        {
            "ver": "1",
            "man": "yes",
            "client": "pc",
            "keyword": keyword,
            "duration": str(int(meta.get("duration") or 0)),
            "hash": hash_,
        },
    )
    candidates = (rsp.json() or {}).get("candidates") or []
    for cand in candidates[:3]:
        cid = cand.get("id")
        accesskey = cand.get("accesskey")
        if not cid or not accesskey:
            continue
        # 先要 krc（逐字），解不出来再退回 lrc（逐句）。
        for fmt in ("krc", "lrc"):
            got = _lyric_http(
                "http://lyrics.kugou.com/download",
                {
                    "ver": "1",
                    "client": "pc",
                    "id": cid,
                    "accesskey": accesskey,
                    "fmt": fmt,
                    "charset": "utf8",
                },
            )
            data = got.json() or {}
            content = data.get("content") or ""
            if data.get("error_code") not in (0, None) or not content:
                continue
            try:
                if fmt == "krc":
                    text = _krc_to_enhanced(_krc_decode(content))
                else:
                    text = base64.b64decode(content).decode("utf-8", "ignore")
            except Exception:
                continue
            text = text.replace("\ufeff", "")
            if text.strip():
                return text
    return ""


_LRCX_LINE = re.compile(r"^\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\](.*)$")
_LRCX_WORD = re.compile(r"<(-?\d+),(-?\d+)>([^<]*)")


def _lrcx_to_enhanced(lrcx):
    """酷我 lrcx → 增强 LRC。

    lrcx 的词标记是 `<a,b>字`：起点 = `(a + b) / 6` 毫秒、时长 = `(a - b) / 6`
    （酷我把毫秒乘了 6 再拆成两半，webhtv 的 `Word.startMs/durationMs` 就是这
    么还原的）。偏移相对本行起点。
    """
    out = []
    for raw in (lrcx or "").replace("\r", "").split("\n"):
        head = _LRCX_LINE.match(raw.strip())
        if not head:
            continue
        minute = int(head.group(1))
        second = int(head.group(2))
        frac = head.group(3) or ""
        millis = int(frac) * (100 if len(frac) == 1 else 10 if len(frac) == 2 else 1)
        line_start = minute * 60000 + second * 1000 + millis
        words = []
        for m in _LRCX_WORD.finditer(head.group(4)):
            a = int(m.group(1))
            b = int(m.group(2))
            text = m.group(3)
            if not text:
                continue
            start = max(0, round((a + b) / 6.0))
            duration = max(0, round((a - b) / 6.0))
            words.append("<%d,%d>%s" % (start, duration, text))
        if words:
            out.append(_enhanced_time(line_start) + "".join(words))
    return "\n".join(out)


def _lyric_fetch_kuwo(rid):
    """酷我：先 mobi 的 lrcx（逐字），拿不到再退回 openapi 的逐句。"""
    try:
        query = (
            "type=lyric&req=2&lrcx=1&rid=%s&songname=&artist=&corp=kuwo&fromchannel=bodian"
            % rid
        )
        url = (
            "http://mlyric.kuwo.cn/mobi.s?f=bodian&q=%s&uid=-1&token="
            % base64.b64encode(query.encode("utf-8")).decode("ascii")
        )
        rsp = _lyric_http(url, None, "https://www.kuwo.cn/")
        content = ((rsp.json() or {}).get("data") or {}).get("content") or ""
        if content:
            text = _lrcx_to_enhanced(base64.b64decode(content).decode("utf-8", "ignore"))
            if text.strip():
                return text
    except Exception:
        pass
    rsp = _lyric_http(
        "https://www.kuwo.cn/openapi/v1/www/lyric/getlyric",
        {"musicId": rid, "httpsStatus": "1"},
        "https://www.kuwo.cn/",
    )
    data = _lyric_json(rsp.text)
    lines = ((data.get("data") or {}).get("lrclist")) or []
    out = []
    for line in lines:
        text = (line.get("lineLyric") or "").strip()
        if not text:
            continue
        try:
            seconds = float(line.get("time") or 0)
        except (TypeError, ValueError):
            seconds = 0.0
        minute = int(seconds // 60)
        out.append("[%02d:%05.2f]%s" % (minute, seconds - minute * 60, text))
    return "\n".join(out)


def _lyric_fetch_lrclib(song_id):
    rsp = _lyric_http("https://lrclib.net/api/get/%s" % song_id, None, "")
    if rsp.status_code != 200:
        return ""
    try:
        data = rsp.json()
    except Exception:
        return ""
    return data.get("syncedLyrics") or data.get("plainLyrics") or ""


def _lyric_fetch(source, payload):
    if source == "netease":
        return _lyric_fetch_netease(payload)
    if source == "qq":
        return _lyric_fetch_qq(payload)
    if source == "kugou":
        return _lyric_fetch_kugou(payload)
    if source == "kuwo":
        return _lyric_fetch_kuwo(payload)
    if source == "lrclib":
        return _lyric_fetch_lrclib(payload)
    return ""


def _proxy_bytes(body):
    """代理正文归一成 bytes（bytes / str / 生成器 / 列表 / 文件对象都认）。"""
    if body is None:
        return b""
    if isinstance(body, bytes):
        return body
    if isinstance(body, (bytearray, memoryview)):
        return bytes(body)
    if isinstance(body, str):
        return body.encode("utf-8")
    if isinstance(body, dict):
        return json.dumps(body, ensure_ascii=False).encode("utf-8")
    if isinstance(body, (list, tuple)):
        return b"".join(_proxy_bytes(item) for item in body)
    if hasattr(body, "read"):
        try:
            return _proxy_bytes(body.read())
        except Exception:
            return b""
    if hasattr(body, "__iter__"):
        try:
            return b"".join(_proxy_bytes(item) for item in body)
        except Exception:
            return b""
    return str(body).encode("utf-8")


def _has_header(headers, name):
    low = name.lower()
    return any(str(key).lower() == low for key in (headers or {}))


class Handler(BaseHTTPRequestHandler):
    # ★HTTP/1.0：每个请求一个连接。1.1 的 keep-alive 会让客户端（Dart
    # HttpClient）复用已被服务端关掉的连接，表现为 Write failed 10053 ——
    # 本地回环上重连的代价可以忽略，稳定性优先。
    protocol_version = "HTTP/1.0"

    def log_message(self, fmt, *args):  # 安静：日志由 Dart 侧收集关键行
        pass

    def _send(self, code, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # 客户端切页/取消时先断了，正常现象。
            pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/health":
            self._send(200, {"ok": True, "sites": sorted(SPIDERS.keys())})
            return
        if path == "/image":
            self._serve_image(parsed.query)
            return
        if path == "/lyricsearch":
            self._serve_lyric_search(parsed.query)
            return
        if path == "/lyricget":
            self._serve_lyric_get(parsed.query)
            return
        # 取流代理：`/site/<stem>/proxy`（base.spider.getProxyUrl 拼出来的）
        # 与 `/proxy?do=py…`（源里写死 9978 的那批）。两条走同一段逻辑。
        parts = [p for p in path.split("/") if p]
        if len(parts) == 3 and parts[0] == "site" and parts[2] == "proxy":
            self._serve_proxy(parts[1], parsed.query)
            return
        if path == "/proxy":
            self._serve_proxy("", parsed.query)
            return
        self._send(404, {"error": "not found"})

    def do_HEAD(self):
        """播放器探测地址时会发 HEAD：只回响应头，不取正文。"""
        parsed = urlparse(self.path)
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) == 3 and parts[0] == "site" and parts[2] == "proxy":
            self._serve_proxy(parts[1], parsed.query, head=True)
            return
        if parsed.path == "/proxy":
            self._serve_proxy("", parsed.query, head=True)
            return
        self._send(404, {"error": "not found"})

    def _serve_image(self, query):
        """`/image?u=<urlencoded>&r=<referer>`：替界面抓图（见 fetch_image）。

        豆瓣不带 Referer 回 418、番茄给的是 HEIC（Skia 不解），这两类图都靠
        这个端点。抓不到就回 502/404，界面按加载失败处理（占位块）。
        """
        params = urllib.parse.parse_qs(query)
        url = (params.get("u") or [""])[0].strip()
        referer = (params.get("r") or [""])[0].strip()
        if not url.lower().startswith(("http://", "https://")):
            self._send(400, {"error": "bad url"})
            return
        try:
            data, mime = fetch_image(url, referer)
        except Exception as exc:
            log_line("图床代抓失败：%s → %s" % (brief(url, 70), exc))
            self._send(502, {"error": str(exc)[:200]})
            return
        try:
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "public, max-age=86400")
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def _serve_lyric_search(self, query):
        """`/lyricsearch?q=&artist=&duration=&token=`：多源歌词搜索（第 53 批）。

        沉浸模式/听歌模式的歌词优先用站源随播放地址下发的 `subs`；很多音乐源
        不给，这时界面上有「搜索歌词」按钮。参考 webhtv：**同时**问网易云、
        QQ 音乐、酷狗、酷我、LRCLIB，各源一个线程。

        轮询协议：首次不带 `token` → 建任务、立刻返回当前（多半是空）快照；
        之后带 `token` 反复问，`done=false` 期间界面每隔几百毫秒再问一次。
        每次快照都按分数重排，所以「后来居上」的候选会自己浮到最上边。
        """
        params = urllib.parse.parse_qs(query)
        keyword = (params.get("q") or [""])[0].strip()
        artist = (params.get("artist") or [""])[0].strip()
        token = (params.get("token") or [""])[0].strip()
        try:
            duration = int((params.get("duration") or ["0"])[0] or 0)
        except ValueError:
            duration = 0

        job = None
        if token:
            with LYRIC_JOBS_LOCK:
                job = LYRIC_JOBS.get(token)
        if job is None:
            if not keyword:
                self._send(400, {"error": "bad q"})
                return
            job = _lyric_start_job(keyword, _lyric_pairs(keyword, artist), duration)
        self._send(200, _lyric_snapshot(job))

    def _serve_lyric_get(self, query):
        """`/lyricget?id=<source>:<payload>`：取候选的 LRC 原文。

        `id` 是搜索阶段下发的**不透明**串（`qq:003JJd7a`、`kugou:<hash>`…），
        前缀决定去哪个站取。旧的无前缀数字 id 仍按网易云处理。
        结果缓存进内存（同一首反复选中不用再出门）；拿不到回 404。
        """
        params = urllib.parse.parse_qs(query)
        raw = (params.get("id") or [""])[0].strip()
        if not raw:
            self._send(400, {"error": "bad id"})
            return
        source, _, payload = raw.partition(":")
        if not payload:
            source, payload = "netease", raw
        cached = LYRIC_CACHE.get(raw)
        if cached is not None:
            self._send(200, {"lyric": cached})
            return
        try:
            lyric = _lyric_fetch(source, payload) or ""
        except Exception as exc:
            log_line("歌词获取失败：%s → %s" % (brief(raw, 60), exc))
            self._send(502, {"error": str(exc)[:200]})
            return
        if not lyric.strip():
            self._send(404, {"error": "no lyric"})
            return
        if len(LYRIC_CACHE) > 96:
            LYRIC_CACHE.clear()
        LYRIC_CACHE[raw] = lyric
        self._send(200, {"lyric": lyric})

    # ---- 取流代理（第 71 批）------------------------------------------------
    #
    # py 源普遍带一个 `localProxy(param)`：把播放地址换成「本机代理 + 参数」，
    # 由它自己去上游取流（带播放器 UA / Referer、改写 m3u8 里的分片和密钥
    # 地址、按 Range 续传）。webhtv 的入口有两个：
    #
    #   GET /site/<key>/proxy?type=m3u8&url=…      ← base.spider.getProxyUrl()
    #   GET /proxy?do=py&type=m3u8&url=…           ← 源里写死的 9978 地址
    #
    # 我们以前只实现了 POST `action=proxy`（Dart 从不这么调），于是：
    #   * 28 个带 localProxy 的源，拿到的代理地址一律 404；
    #   * 瓜子（CDN 按 UA 判片，必须走代理）直接播不了。
    def _serve_proxy(self, key, query, head=False):
        params = {}
        for name, values in urllib.parse.parse_qs(
            query, keep_blank_values=True
        ).items():
            params[name] = values[0] if len(values) == 1 else values[-1]
        # 请求头也并进 param：webhtv 同样把 session headers 合进来，源里会读
        # `Range` / `User-Agent` / `Referer`（大小写两套都给，省得源挑写法）。
        for name, value in self.headers.items():
            params.setdefault(name.lower(), value)
            params.setdefault(name, value)
        site = (
            key
            or params.get("siteKey")
            or params.get("site")
            or params.get("do_site")
            or LAST_SITE
        )
        site = str(site or "").strip()
        if not site:
            self._send(400, {"error": "no site for proxy"})
            return
        # ★第 159 批：`do=ck` 且没有显式站点 = 源 jar 的 Proxy.getUrl() 端口
        #   扫描探针（9978..9999 找回 ok 的本地代理）。落到桥上时快速 404
        #   让路 —— 别钻进 localProxy 白磨 2 秒（这台机器拒绝连接要 2 秒，
        #   扫描段 21 个端口磨出 30 秒起播延迟，就是这批探针干的）。真正
        #   应答探针的是 jarsite 的转发 hub（占在 9979 起的扫描段里）。
        if (
            params.get("do") == "ck"
            and not key
            and not params.get("siteKey")
            and not params.get("site")
            and not params.get("do_site")
        ):
            self._send(404, {"error": "probe"})
            return
        try:
            spider = get_spider(site)
            result = spider.localProxy(params)
        except Exception as exc:
            log_line("[%s] proxy 失败：%s" % (site, exc))
            try:
                self._send(500, {"error": str(exc)[:300]})
            except Exception:
                pass
            return
        self._write_proxy(result, head=head)

    def _write_proxy(self, result, head=False):
        """把 `localProxy` 的返回值原样写成 HTTP 响应。

        契约同 webhtv：`[状态码, MIME, 正文, 响应头]`；正文可以是 bytes /
        str / None（配合 Location 做 302）/ 生成器（分片流）/ 列表。
        """
        if result is None:
            self._send(404, {"error": "no proxy result"})
            return
        if isinstance(result, (bytes, bytearray, memoryview, str)):
            self._write_proxy_raw(200, "application/octet-stream", result, {}, head)
            return
        if not isinstance(result, (list, tuple)) or len(result) < 3:
            self._send(500, {"error": "invalid proxy response"})
            return
        try:
            code = int(result[0])
        except (TypeError, ValueError):
            code = 500
        mime = result[1] if isinstance(result[1], str) and result[1] else ""
        headers = result[3] if len(result) > 3 and isinstance(result[3], dict) else {}
        self._write_proxy_raw(code, mime, result[2], headers, head)

    def _write_proxy_raw(self, code, mime, body, headers, head=False):
        data = _proxy_bytes(body)
        # ★源在 m3u8 正文里把分片/密钥地址拼成了写死的 9978（第 71 批）：
        # 本机 9978 不一定归我们（可能被别的服务占着，实测就有），所以直接把
        # 正文里的老地址改成本桥真实端口。只在文本清单上做，二进制分片不动。
        if data and PORT and PORT != 9978 and b"127.0.0.1:9978" in data:
            text_like = (
                "mpegurl" in (mime or "").lower()
                or "text" in (mime or "").lower()
                or data.lstrip()[:8].startswith(b"#EXTM3U")
            )
            if text_like:
                data = data.replace(
                    b"127.0.0.1:9978",
                    ("127.0.0.1:%d" % PORT).encode("ascii"),
                )
        skip = {"content-length", "transfer-encoding", "connection"}
        try:
            self.send_response(code)
            for name, value in (headers or {}).items():
                if name is None or value is None:
                    continue
                if str(name).lower() in skip:
                    continue
                self.send_header(str(name), str(value))
            if mime and not _has_header(headers, "content-type"):
                self.send_header("Content-Type", mime)
            # HTTP/1.0 短连接：给了长度客户端才好按 Range 续播、也能立刻收尾。
            if code not in (204, 304):
                self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            if not head and data and code not in (204, 304):
                self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # 播放器切线路/关窗时先断了，正常现象。
            pass

    def _read_body(self):
        """读请求体：既认 Content-Length，也认 chunked。

        ★chunked 这条不是可选项：Dart 的 `HttpClientRequest.write()` 在不设
        contentLength 时会发 `Transfer-Encoding: chunked`，而
        `BaseHTTPRequestHandler` 不会替我们解码 —— 只按 Content-Length 读就会
        读到空 body，等于所有参数都丢了（第 41 批就是这么炸的：详情为空、
        分类串味、搜索关键词为空）。这边兜住，客户端怎么发都不会再丢。
        """
        transfer = (self.headers.get("Transfer-Encoding") or "").lower()
        if "chunked" in transfer:
            chunks = []
            while True:
                line = self.rfile.readline(65536)
                if not line:
                    break
                size_text = line.split(b";")[0].strip()
                try:
                    size = int(size_text, 16)
                except ValueError:
                    break
                if size <= 0:
                    # 末尾的 CRLF 与（可选的）trailer
                    self.rfile.readline(65536)
                    break
                chunks.append(self.rfile.read(size))
                self.rfile.read(2)  # 每块后面的 CRLF
            return b"".join(chunks)
        length = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(length) if length > 0 else b"{}"

    def do_POST(self):
        path = urlparse(self.path).path
        raw = self._read_body()
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
            if not isinstance(body, dict):
                body = {}
        except Exception:
            body = {}

        parts = [p for p in path.split("/") if p]
        # ★/hook/ui —— JVM 桩上报的「源内 UI 事件」（第 163 批）：源以为
        # 自己在 Android 上弹的扫码窗 / 输入框 / Toast，序列化成 JSON 攒到
        # UI_EVENTS，由 action 响应捎回给 App。
        # ★第 181 批：交互窗事件带 wait:true —— 这条 HTTP **挂起不回**，
        # 等 /ui/respond 把 {"button","values"} 送回来才结束（桩的守护
        # 线程醒来接着跑源自己的按钮回调）。kind=cancel-wait 是源主动
        # dismiss 交互窗：把挂起的那条按「取消」收尾。
        if len(parts) == 2 and parts[0] == "hook" and parts[1] == "ui":
            kind = str(body.get("kind") or "")
            if kind == "cancel-wait":
                # ★182：桩给的是窗 id，反查成等待号；老桩给的就是等待号。
                raw = str(body.get("dialog") or body.get("id") or "")
                waiter_respond(raw, {"button": "cancel"})
                self._send(200, {"ok": True})
                return
            waiting = body.get("wait") is True
            if waiting:
                with UI_WAITERS_LOCK:
                    UI_WAIT_SEQ[0] += 1
                    wait_id = str(UI_WAIT_SEQ[0])
                    stub_id = str(body.get("dialog") or "")
                    body["id"] = wait_id
                    UI_WAITERS[wait_id] = {
                        "event": threading.Event(), "resp": None,
                    }
                    if stub_id:
                        UI_WAIT_BY_DIALOG[stub_id] = wait_id
            push_ui_event(body if body else {"kind": "dialog", "texts": []})
            log_line("[ui-hook] %s" % json.dumps(body, ensure_ascii=False)[:200])
            if not waiting:
                self._send(200, {"ok": True})
                return
            waiter = UI_WAITERS.get(wait_id)
            fired = waiter is not None and waiter["event"].wait(UI_WAIT_TIMEOUT)
            with UI_WAITERS_LOCK:
                waiter = UI_WAITERS.pop(wait_id, None)
                for k in [k for k, v in UI_WAIT_BY_DIALOG.items() if v == wait_id]:
                    UI_WAIT_BY_DIALOG.pop(k, None)
            resp = waiter.get("resp") if (fired and waiter) else None
            if not isinstance(resp, dict):
                resp = {"button": "cancel"}
            self._send(200, resp)
            return
        # ★/ui/respond —— App 端双向对话框的回传（第 181 批）。
        # ★第 184 批：多带一个 `choice`（单选列表选中的下标）—— 潇洒的
        # 画质 / 线程窗靠它把用户选的项交给源的 item 回调。
        if len(parts) == 2 and parts[0] == "ui" and parts[1] == "respond":
            wait_id = str(body.get("id") or "")
            values = body.get("values")
            payload = {
                "button": str(body.get("button") or "cancel"),
                "values": values if isinstance(values, list) else [],
            }
            choice = body.get("choice")
            try:
                if isinstance(choice, bool) or choice is None:
                    raise ValueError
                payload["choice"] = int(choice)
            except (TypeError, ValueError):
                pass
            # ★184：多选窗（潇洒的「主页分类」）—— 勾选集合原样带给桩，
            # 桩按位回调源自己的 OnMultiChoiceClickListener。
            picked = body.get("choices")
            if isinstance(picked, list):
                try:
                    payload["choices"] = [int(x) for x in picked
                                          if not isinstance(x, bool)]
                except (TypeError, ValueError):
                    pass
            # ★第 188 批：用户点了源窗里的「可点行」—— 把行号带给桩，
            # 桩直接回调源自己的 OnClickListener（摸鱼设置中心整页都是自绘行）。
            act = body.get("action")
            try:
                if isinstance(act, bool) or act is None:
                    raise ValueError
                payload["action"] = int(act)
            except (TypeError, ValueError):
                pass
            ok = waiter_respond(wait_id, payload)
            self._send(200, {"ok": bool(ok)})
            return
        # ★/ui/poll —— 源内 UI 事件的「续拉」（第 165 批）。
        #
        # 源的扫码登录是异步的：action 立刻返回，真正结果由源自己的轮询线程
        # 在几十秒后才弹 Toast / 关窗。App 在动作执行完后短期轮询这里取增量，
        # 所以「百度网盘授权成功」不会再被吞掉。
        if len(parts) == 2 and parts[0] == "ui" and parts[1] == "poll":
            try:
                since = int(body.get("since") or 0)
            except (TypeError, ValueError):
                since = 0
            events, seq = ui_events_since(since)
            self._send(200, {"events": events, "seq": seq})
            return
        # ★第 189 批：网盘登录闭环的两条专用路由。
        #
        #   POST /pan/state {site}         → 各标准盘是否已登录（不碰 JVM）
        #   POST /pan/scan  {site,brand}   → 代按 `<盘>_scan`，把这次动作期间
        #                                    冒出来的扫码窗事件一起捎回去
        #
        # 为什么要单开两条，而不是让 App 直接 `action("<盘>_scan")`：
        # 扫码入口不在播放站点身上（玩偶 4K 的 action 只回 `{}`），而在**同一个
        # 订阅的设置中心站点**上；「该找哪个站点」要看 sites.json 的 `_dir`，
        # 这份清单只有 Python 侧有。App 不该为了按一个按钮去认这些。
        if len(parts) == 2 and parts[0] == "pan" and parts[1] == "state":
            self._send(200, pan_login_state(body.get("site")))
            return
        if len(parts) == 2 and parts[0] == "pan" and parts[1] == "scan":
            self._send(200, pan_login_scan(body.get("site"), body.get("brand")))
            return
        # /site/<key>/<action>
        if len(parts) != 3 or parts[0] != "site":
            self._send(404, {"error": "not found"})
            return
        key, action = parts[1], parts[2]
        try:
            result = call_action(key, action, body)
            self._send(200, result)
        except Exception as exc:
            detail = traceback.format_exc(limit=6)
            sys.stderr.write(detail + "\n")
            log_line("[%s] %s 失败：%s" % (key, action, exc))
            try:
                self._send(500, {"error": str(exc) or exc.__class__.__name__})
            except Exception:
                # 客户端先走了（切页/取消搜索）会写不出去，不算错误。
                pass


def prune_img_cache(days=7):
    """清掉 7 天没用过的图床缓存，别让 imgcache 无限长。"""
    try:
        cutoff = time.time() - days * 86400
        for name in os.listdir(IMG_CACHE_DIR):
            path = os.path.join(IMG_CACHE_DIR, name)
            try:
                if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
                    os.remove(path)
            except Exception:
                pass
    except Exception:
        pass


def shutdown_jvms(reason=""):
    """把本桥起过的 JVM 全关掉（第 190 批）。

    ★为什么必须显式关：JVM 是桥的子进程，桥一死它就是孤儿，每个 -Xmx384m
    常驻。用户机器上实测开关四次软件攒了四个 java.exe，内存被吃干净，表现
    就是「关闭软件时未响应、很慢」。三条收尾路径都挂上它：
      - 正常退出（atexit）
      - 收到 SIGTERM / SIGINT
      - 宿主观测线程发现宿主没了（watch_parent，那之后是 os._exit，不跑 atexit）
    """
    try:
        import jarsite

        jarsite.shutdown_all()
        if reason:
            try:
                print("[bridge] 关闭 JVM（%s）" % reason, file=sys.stderr, flush=True)
            except Exception:
                pass
    except Exception:
        pass


def _install_exit_hooks():
    """进程退出（含被软杀）时关 JVM。硬杀（TerminateProcess）拦不住 ——
    那条路交给 jarsite._assign_to_job 的 Job 兜底。"""
    atexit.register(shutdown_jvms, "atexit")

    def handler(signum, _frame):
        shutdown_jvms("signal %s" % signum)
        os._exit(0)

    for name in ("SIGTERM", "SIGINT", "SIGBREAK"):
        sig = getattr(signal, name, None)
        if sig is None:
            continue
        try:
            signal.signal(sig, handler)
        except Exception:
            pass


def watch_parent(pid):
    """宿主（wmys.exe）没了就自己退出。

    ★桥是 detached 进程：App 崩溃、任务管理器结束、构建脚本 taskkill 都带不走它。
    残留的 python.exe 会一直占着 `runtime\\pyspider` 下的 python313.zip / *.pyd，
    下一次出包拷不进去 → 运行时残缺 → 软件「构建后没有数据」。
    """
    if not pid:
        return

    def run():
        try:
            import ctypes

            k32 = ctypes.windll.kernel32
        except Exception:
            return  # 非 Windows / 没 ctypes：不启用看门狗
        query_limited = 0x1000
        still_active = 259
        code = ctypes.c_ulong()
        # ★第 185 批：宿主死因取证。以前只记「已退出」不记退出码，
        # 用户报「软件自己关闭」时判不了是干净 exit 还是崩溃。
        # 0 = exit(0) 干净退出；0xC0000005 = 访问违例崩溃；259 还活着不该走到这。
        reason = "OpenProcess 失败（GetLastError=0x%08X）" % (k32.GetLastError() & 0xFFFFFFFF)
        while True:
            time.sleep(2.0)
            try:
                handle = k32.OpenProcess(query_limited, False, int(pid))
            except Exception:
                return
            if not handle:
                break
            ok = k32.GetExitCodeProcess(handle, ctypes.byref(code))
            k32.CloseHandle(handle)
            if not ok or code.value != still_active:
                if not ok:
                    reason = "GetExitCodeProcess 失败（GetLastError=0x%08X）" % (
                        k32.GetLastError() & 0xFFFFFFFF
                    )
                else:
                    reason = "exitcode=0x%08X" % (code.value & 0xFFFFFFFF)
                break
        log_line("宿主进程 %s 已退出（%s），桥自行结束" % (pid, reason))
        # ★第 190 批：os._exit 不跑 atexit —— JVM 得在这里亲手关，
        #   否则宿主一关就留下一串孤儿 java.exe（正是「关闭软件很慢」的元凶）。
        shutdown_jvms("宿主已退出")
        os._exit(0)

    threading.Thread(target=run, daemon=True).start()


def main():
    global SITES_DIR, CACHE_DIR, PORT, IMG_CACHE_DIR, DASH_CACHE_DIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--sites", required=True)
    parser.add_argument("--cache", default="")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--log", default="")
    parser.add_argument("--parent", type=int, default=0)
    args = parser.parse_args()

    # ★Dart 侧用分离进程拉起（不走管道），所以端口由它指定、日志落文件；
    # 这个环境里创建进程管道会失败（ERROR_PIPE_BUSY），不能依赖 stdout。
    if args.log:
        try:
            fh = open(args.log, "a", encoding="utf-8", buffering=1)
            sys.stdout = fh
            sys.stderr = fh
        except Exception:
            pass

    SITES_DIR = os.path.abspath(args.sites)
    CACHE_DIR = os.path.abspath(args.cache or args.sites)
    os.makedirs(SITES_DIR, exist_ok=True)
    os.makedirs(CACHE_DIR, exist_ok=True)
    # 图床缓存放在站点目录下（跟着 wmdata 走，卸载时一起清）。
    IMG_CACHE_DIR = os.path.join(SITES_DIR, "imgcache")
    os.makedirs(IMG_CACHE_DIR, exist_ok=True)
    DASH_CACHE_DIR = os.path.join(SITES_DIR, "mpdcache")
    os.makedirs(DASH_CACHE_DIR, exist_ok=True)
    prune_img_cache()
    # ★第 190 批：上一轮被硬杀/崩溃时留下的孤儿 JVM 先收尸（每个吃 384MB
    #   堆，攒几个机器就卡）。必须在起新 JVM 之前做，此刻池子还是空的，
    #   「还活着的我们这套 jre 下的 java.exe」必然是遗留。
    try:
        import jarsite

        jarsite.reap_orphan_jvms(SITES_DIR)
    except Exception:
        pass
    _install_exit_hooks()
    watch_parent(args.parent)

    # py 源大量 requests.verify=False → urllib3 每条请求刷三行
    # InsecureRequestWarning，能把 bridge.log 冲成没法看。业务日志比它重要。
    try:
        import urllib3

        urllib3.disable_warnings()
    except Exception:
        pass

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.daemon_threads = True
    PORT = server.server_address[1]
    base_spider.PROXY_PORT = PORT
    # ★第 163 批：把桥端口塞进环境变量，JVM 桩（UiHook）上报源内 UI 事件用。
    # 子进程（SpiderRunner JVM）继承本进程环境，不用改 spawn 处。
    os.environ["WMYS_HOOK_PORT"] = str(PORT)
    print("PORT:%d" % PORT, flush=True)

    # ★另开一个 9978 监听（第 71 批）：一部分 py 源把宿主地址写死成
    # `http://127.0.0.1:9978/…`（瓜子 `PROXY_BASE`、danmaku 之类）。Dart 侧
    # 会把播放地址里的 9978 改写成真实端口，但**源自己在 m3u8 正文里拼的
    # 分片/密钥地址**改不到 —— 多听一个端口最省事；9978 被占用就静默跳过。
    if PORT != 9978:
        try:
            legacy = ThreadingHTTPServer(("127.0.0.1", 9978), Handler)
            legacy.daemon_threads = True
            threading.Thread(target=legacy.serve_forever, daemon=True).start()
            log_line("兼容监听 127.0.0.1:9978（源里写死的老地址）")
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
