# -*- coding: utf-8 -*-
"""TVBox py 源运行时的基类（无名影视 Windows 版）。

对应 FongMi/猫影视 里 `base.spider.Spider` 的公共接口：py 源脚本
`from base.spider import Spider` 后继承本类，运行时提供 fetch/post/html
等便利方法。原版基类依赖 Android 的 `com.github.catvod.Proxy`，这里改成
纯 Python：缓存走本进程内存，代理地址指向本桥服务。
"""

import json
import os
import re
import sys
import time

import requests
from lxml import etree


# 进程内缓存：`/site/<key>/cache` 与 Spider.getCache 共用。
CACHE = {}


class Spider(object):
    """py 源基类：所有钩子默认空实现，脚本按需覆盖。"""

    _instance = None

    def __init__(self):
        self.extend = ""

    def __new__(cls, *args, **kwargs):
        # 与 FongMi 一致：同一个脚本只留一个实例（py 源里普遍这么假设）。
        if cls.__dict__.get("_instance"):
            return cls.__dict__["_instance"]
        obj = super().__new__(cls)
        cls._instance = obj
        return obj

    # ---- TVBox 协议钩子 ----

    def init(self, extend=""):
        pass

    def homeContent(self, filter):
        pass

    def homeVideoContent(self):
        pass

    def categoryContent(self, tid, pg, filter, extend):
        pass

    def detailContent(self, ids):
        pass

    def searchContent(self, key, quick, pg="1"):
        pass

    def playerContent(self, flag, id, vipFlags):
        pass

    def liveContent(self, url):
        pass

    def localProxy(self, param):
        pass

    def isVideoFormat(self, url):
        pass

    def manualVideoCheck(self):
        pass

    def action(self, action):
        pass

    def destroy(self):
        pass

    def getName(self):
        pass

    def getDependence(self):
        return []

    # ---- 便利方法（与原版同名同签名）----

    def fetch(self, url, params=None, cookies=None, headers=None, timeout=5,
              verify=True, stream=False, allow_redirects=True):
        rsp = requests.get(url, params=params, cookies=cookies, headers=headers,
                           timeout=timeout, verify=verify, stream=stream,
                           allow_redirects=allow_redirects)
        rsp.encoding = "utf-8"
        return rsp

    def post(self, url, params=None, data=None, json=None, cookies=None,
             headers=None, timeout=5, verify=True, stream=False,
             allow_redirects=True):
        rsp = requests.post(url, params=params, data=data, json=json,
                            cookies=cookies, headers=headers, timeout=timeout,
                            verify=verify, stream=stream,
                            allow_redirects=allow_redirects)
        rsp.encoding = "utf-8"
        return rsp

    def html(self, content):
        return etree.HTML(content)

    @staticmethod
    def str2json(value):
        return json.loads(value)

    @staticmethod
    def json2str(value):
        return json.dumps(value, ensure_ascii=False)

    def regStr(self, reg, src, group=1):
        m = re.search(reg, src)
        return m.group(group) if m else ""

    def removeHtmlTags(self, src):
        return re.sub(re.compile("<.*?>"), "", src)

    def cleanText(self, src):
        return re.sub(
            "[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF"
            "\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]",
            "",
            src,
        )

    def loadModule(self, name):
        from importlib.machinery import SourceFileLoader

        path = os.path.join(PY_DIR, f"{name}.py")
        return SourceFileLoader(name, path).load_module()

    def loadSpider(self, name):
        return self.loadModule(name).Spider()

    # 代理与缓存：由 bridge.py 注入 actual 端口后生效。
    def getProxyUrl(self, local=True):
        return f"http://127.0.0.1:{PROXY_PORT}/site/{SITE_KEY}/proxy"

    def getCache(self, key):
        item = CACHE.get(key)
        if not item:
            return None
        value, expires_at = item
        if expires_at and expires_at < time.time():
            CACHE.pop(key, None)
            return None
        return value

    def setCache(self, key, value):
        CACHE[key] = (value, 0)
        return "succeed"

    def delCache(self, key):
        CACHE.pop(key, None)
        return "succeed"

    def log(self, msg):
        if isinstance(msg, (dict, list)):
            print(json.dumps(msg, ensure_ascii=False))
        else:
            print(msg)


# bridge.py 在加载脚本前设置这三项。
PY_DIR = ""
PROXY_PORT = 0
SITE_KEY = ""
