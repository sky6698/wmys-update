# -*- coding: utf-8 -*-
"""jar 形态站点（TVBox 的 spider jar）在 py 桥里的通道 —— 第 140 批。

链路
----
订阅根 `spider` 字段给一个 jar 地址，站点表里的 api 是 jar 内的类名
（`csp_Jianpian`）。Dart 侧把 jar 下到 `wmdata/jarsites/<订阅 id>/spider.jar`
并写出 `sites.json`（站点 key → 类名 + ext + 开关）；这里按 key 找到类名，
转给 JVM 里的 SpiderRunner 执行。

依赖
----
* JVM：**只认** `wmdata/plugins/jarspider`（用户导入的组件）。★不再去翻
  Win-Box 之类外部软件的安装目录（第 144 批）：那会把 jar 源绑在别人的安装
  路径上，也让「我明明没装却能用」变得难以解释。没装就报未安装，等用户导入。
* 一个 jar 一个 JVM（`SpiderRunner --serve <jar>` 一次只认一份 jar），按需起、
  常驻复用；同一个 jar 里的所有站点共用它。

只依赖标准库，Python 3.10+。
"""
import hashlib
import json
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer  # noqa: E402
import urllib.request  # noqa: E402
from urllib.parse import quote  # noqa: E402

_LOCK = threading.RLock()
_CONV_LOCK = threading.Lock()  # jar 转换（dex2jar）串行，见 _jvm_for
_POOL = {}       # jar 路径 -> JarJvm
_SITES = {}      # 站点 key -> spec（来自 sites.json）
_SITES_AT = 0.0  # 上次扫描时间

# 守卫未就绪时 SpiderRunner 会回这一串（此时要等，不是失败）
_GUARD = "hostAdmission"


def _guard_state(data):
    """响应里守卫怎么说的；跟守卫无关返回 `None`。

    ★第 148 批：`_send` 回的是 SpiderRunner 吐的**原始文本**
      （`{"hostAdmission":"pending"}`）。以前这里写成
      `isinstance(data, dict) and data.get(_GUARD) == "pending"` —— 永远
      不成立，于是「守卫 pending → 自动换回上一版 jar」那条分支是死代码，
      用户遇到换壳的 jar 只能看着 97 个站点全部报「宿主校验未通过」。
    """
    if data is None:
        return None
    text = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
    if _GUARD not in text:
        return None
    try:
        obj = json.loads(text)
    except Exception:
        # 不是规整 JSON 却又提到守卫 → 当成未放行。
        return "pending"
    if isinstance(obj, dict):
        value = obj.get(_GUARD)
        return None if value is None else str(value)
    return "pending"

# ★别弹控制台窗口（第 144 批）：桥是 `Process.start(detached)` 起的，本身没有
#   控制台，再 Popen 一个 java.exe（控制台子系统）系统就会**新开一个黑窗口**。
#   实测打开 jar 源会蹦出两个 —— dxe2jar 转换一个、SpiderRunner 一个。
#   CREATE_NO_WINDOW 让系统不给它建控制台，stdin/stdout 管道照常工作。
_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
_SPAWN = {"creationflags": _NO_WINDOW} if os.name == "nt" else {}

# 站点 JVM 的堆（第 194 批）：见 JvmProcess._argv 里的说明。
# 用环境变量能压回去，排查「内存吃紧」时不必改代码。
_JVM_HEAP = (os.environ.get("WMYS_JVM_HEAP") or "768m").strip() or "768m"


def _heap_arg():
    """`-Xmx…` 参数（第 194 批）。堆上限不许写成空串或非法值。"""
    value = _JVM_HEAP
    if not value or not value[0].isdigit():
        value = "768m"
    return "-Xmx" + value


# --------------------------------------------------------------------------
# Windows Job：给 JVM 上「持有者一死就整组收尸」的保险（第 190 批）
# --------------------------------------------------------------------------

_JOB_HANDLES = []   # 长持句柄 —— 不能关，句柄一关等于立刻把 job 里的进程全杀


def _assign_to_job(proc):
    """把刚起的子进程挂进 `KILL_ON_JOB_CLOSE` 的 Job。

    ★为什么非要有这一层（第 190 批实测）：
      桥是 detached 进程，宿主（wmys.exe）退出后桥可能被 TerminateProcess
      **硬杀** —— 那种死法不跑 atexit、不接信号，桥根本没机会去关 JVM。
      JVM 本来自救的路子是「stdin 出 EOF 就退」，可 SpiderRunner 以前只
      `return` 不 `System.exit`，源里那堆非 daemon 线程（OkHttp 连接池、
      Fish 的 Handler、catvod Proxy 的监听…）把 JVM 吊住不退。
      两条路都断了就只剩内核兜底：Job 一关，组内进程（含孙进程）全杀。

    失败静默（老系统不支持嵌套 Job / 权限不足）：还有 SpiderRunner 的
    `exitNow` 兜着，不会回到「一堆孤儿 java.exe」。
    """
    if os.name != "nt" or proc is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        if not _JOB_HANDLES:
            k32.CreateJobObjectW.restype = wintypes.HANDLE
            k32.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]
            job = k32.CreateJobObjectW(None, None)
            if not job:
                return False
            # JOBOBJECT_EXTENDED_LIMIT_INFORMATION：实测 144 字节，
            # LimitFlags 在偏移 16；0x2000 = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE。
            info = ctypes.create_string_buffer(144)
            ctypes.memset(info, 0, 144)
            ctypes.cast(
                ctypes.addressof(info) + 16,
                ctypes.POINTER(ctypes.c_uint32),
            )[0] = 0x2000
            if not k32.SetInformationJobObject(job, 9, info, 144):
                k32.CloseHandle(job)
                return False
            _JOB_HANDLES.append(job)   # 故意不关：句柄活着，Job 才活着
        handle = int(proc._handle)
        return bool(k32.AssignProcessToJobObject(
            _JOB_HANDLES[0], wintypes.HANDLE(handle)))
    except Exception:
        return False


def reap_orphan_jvms(sites_dir):
    """清掉上一轮留下的孤儿 JVM，返回杀掉的个数。

    桥刚起来、`_POOL` 还是空的 —— 此刻还活着的 `jarspider\\jre\\bin\\java.exe`
    必然是上一轮遗留（旧版关软件不杀 JVM，用户机器上实测攒到四个）。
    按**可执行文件全路径**比对，不按 pid 复用猜，避免杀错别人的 java。
    """
    if os.name != "nt":
        return 0
    try:
        rt = find_runtime(sites_dir)
    except Exception:
        return 0
    if not rt or not rt.get("java"):
        return 0
    target = os.path.normcase(os.path.abspath(rt["java"]))
    try:
        import ctypes
        from ctypes import wintypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD),
                ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", wintypes.WCHAR * 260),
            ]

        k32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        sn = k32.CreateToolhelp32Snapshot(0x00000002, 0)  # TH32CS_SNAPPROCESS
        if not sn or int(sn) in (-1, 0xFFFFFFFFFFFFFFFF):
            return 0
        killed = 0
        try:
            entry = PROCESSENTRY32W()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            ok = k32.Process32FirstW(sn, ctypes.byref(entry))
            while ok:
                if (entry.szExeFile or "").lower() == "java.exe":
                    pid = int(entry.th32ProcessID)
                    # PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE
                    h = k32.OpenProcess(0x1000 | 0x0001, False, pid)
                    if h:
                        try:
                            size = wintypes.DWORD(1024)
                            buf = ctypes.create_unicode_buffer(1024)
                            if k32.QueryFullProcessImageNameW(
                                    h, 0, buf, ctypes.byref(size)):
                                if os.path.normcase(buf.value) == target:
                                    if k32.TerminateProcess(h, 1):
                                        killed += 1
                        finally:
                            k32.CloseHandle(h)
                ok = k32.Process32NextW(sn, ctypes.byref(entry))
        finally:
            k32.CloseHandle(sn)
        if killed:
            try:
                # 桥把 stdout/stderr 都重定向进了 bridge.log，够用。
                print("[jarsite] 已清理 %d 个上一轮遗留的 JVM" % killed,
                      file=sys.stderr, flush=True)
            except Exception:
                pass
        return killed
    except Exception:
        return 0



# --------------------------------------------------------------------------
# 路径
# --------------------------------------------------------------------------

def wmdata_of(sites_dir):
    """`wmdata/pysites` -> `wmdata`。"""
    return os.path.dirname(os.path.abspath(sites_dir))


def jarsites_dir(sites_dir):
    return os.path.join(wmdata_of(sites_dir), "jarsites")


def find_runtime(sites_dir):
    """找用户装的 JVM 运行时，返回 dict；没装返回 None。

    ★只认 `wmdata/plugins/jarspider`（第 144 批）：以前还会去各盘符的
    `Program Files` 里翻 Win-Box 的 `jvm/` 目录顶着用 —— 那等于把 jar 源
    绑在别人的安装目录上（用户要求别碰 Win-Box）。没装就返回 None，
    上层如实报「运行环境未安装」，等用户导入组件。
    """
    root = os.path.join(wmdata_of(sites_dir), "plugins", "jarspider")
    java = os.path.join(root, "jre", "bin", "java.exe")
    if not os.path.exists(java):
        return None
    return _layout(root, java)


def _one(*parts):
    p = os.path.join(*parts)
    return p if os.path.exists(p) else ""


def _layout(root, java):
    """把组件目录整理成一组路径。"""
    # 组件把 jar 平铺在 bridge/ 下（也兼容 Win-Box 那套同名目录布局）
    stubs = _one(root, "bridge", "stubs.jar") or _one(root, "stubs", "stubs.jar")
    bridge = _one(root, "bridge", "native-bridge.jar") or _one(
        root, "native-bridge", "native-bridge.jar")
    shim = _one(root, "prefs-shim", "winbox-prefs-shim.jar") or _one(
        root, "bridge", "winbox-prefs-shim.jar")
    compat = _one(root, "okhttp4-compat", "winbox-okhttp4-compat.jar") or _one(
        root, "bridge", "winbox-okhttp4-compat.jar")
    libs = _one(root, "libs") or _one(root, "bridge", "libs")
    # ★第 166 批：okhttp 读超时补丁（覆盖 okhttp3.OkHttpClient）。
    #   源的 `k.b.a()` 写死 readTimeout(30s)，而百度扫码的 channel/unicast
    #   长轮询实测 29.9~30.3 秒才回 —— 客户端几乎每次先超时，扫码结果永远
    #   拿不到。补丁只抬「下限」到 90s，见 build/cfr_okhttp。
    netfix = _one(root, "bridge", "netfix.jar") or _one(root, "netfix.jar")
    d2j = _one(root, "d2j")
    # unidbg 只在组件里找（★不再去 Win-Box 的 data/winbox-cache 翻，第 144 批）
    unidbg = _one(root, "unidbg")
    return {
        "root": root, "java": java, "stubs": stubs, "bridge": bridge,
        "shim": shim, "compat": compat, "libs": libs, "d2j": d2j,
        "netfix": netfix, "unidbg": unidbg,
    }


def _d2j_cp(rt):
    d = rt.get("d2j") or ""
    try:
        return ";".join(
            os.path.join(d, f) for f in os.listdir(d) if f.endswith(".jar"))
    except Exception:
        return ""


# --------------------------------------------------------------------------
# 网盘账号池（第 187 批）
#
# 为什么要有这一节
# ----------------
# 用户报「潇洒源的配置中心能扫码登录，换成摸鱼源这些功能又不能用了；我们
# 要的是任何 jar 源都能用，不用每个源单独实现」。
#
# 实测四个 jar 站点（见 docs/网盘账号通用化-评估报告.md）：
#   · 潇洒 4007 个类，自带 Pan 系全套 SDK，凭证写在 `ext/TVBox/*.txt`；
#   · 摸鱼 1378 个类，走 Fish 框架，账号中心是另一套；
#   · 两者**互不相通**，而且凭证按站点隔离（第 165 批的 `-Dwmys.extdir`），
#     在一个源登录过的号，换源等于没登录 —— 这就是「又坏了」的真相。
#
# 解决办法不是再去兼容某个源的 UI（前 163/165/182/184/186 批都试过，换源
# 就归零），而是把「账号」从源里拿出来：
#
#   ① 账号级唯一池：`wmdata/pan/vault.json`；
#   ② 站点启动前把池**投影**成该源认识的文件（源一个字节都不用改）；
#   ③ 站点停下时把源新写的文件**回收**进池；
#   ④ 池是唯一权威，多源之间自然互通（一次登录，处处可用）。
#
# 文件名沿用通用云盘 SDK 的约定（`baidu.txt` / `quark_cookie.txt` …），
# 内容就是源自己写的原始 JSON，**不做任何转换** —— 取出来直接落盘即可。
# --------------------------------------------------------------------------

# 盘 → 源认的文件名。只收「标准盘」，`diy_cookie.txt` 是各源自定义的口袋，
# 含义随源而变，不参与互通（免得把一个源的私有配置灌给另一个源）。
_PAN_FILES = {
    "baidu": "baidu.txt",
    "quark": "quark_cookie.txt",
    "uc": "uc_cookie.txt",
    "aliyun": "aliyun.txt",
    "bili": "bili_cookie.txt",
    "xunlei": "xunlei.txt",
    "guangya": "guangya.txt",
}
_PAN_BY_FILE = {v: k for k, v in _PAN_FILES.items()}

# 源的凭证根目录（相对站点 work）：`-Dwmys.extdir` 指到 work/ext，
# 源自己拼的是 `Environment.getExternalStorageDirectory()/TVBox`。
_PAN_SUBDIR = os.path.join("ext", "TVBox")


def pan_dir(sites_dir):
    """`wmdata/pan` —— 账号池与它的日志。"""
    return os.path.join(wmdata_of(sites_dir), "pan")


def pan_vault_path(sites_dir):
    return os.path.join(pan_dir(sites_dir), "vault.json")


def _pan_trace(sites_dir, text):
    """账号池的动作全落 `wmdata/pan/pan.log`（用户自查 + 我们排障都用得上）。"""
    try:
        p = os.path.join(pan_dir(sites_dir), "pan.log")
        os.makedirs(os.path.dirname(p), exist_ok=True)
        if os.path.exists(p) and os.path.getsize(p) > 256 * 1024:
            try:
                os.replace(p, p + ".old")
            except Exception:
                pass
        with open(p, "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (time.strftime("%m-%d %H:%M:%S"), text))
    except Exception:
        pass


def pan_vault_load(sites_dir):
    """读池；坏文件当空池（宁可丢互通，也不能让站点起不来）。"""
    try:
        with open(pan_vault_path(sites_dir), encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("accounts"), dict):
            return data
    except Exception:
        pass
    return {"version": 1, "accounts": {}}


def pan_vault_save(sites_dir, data):
    """原子写池（第 186 批 zip 写坏过，这里一律临时文件 + replace）。"""
    p = pan_vault_path(sites_dir)
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, p)
        return True
    except Exception as exc:
        _pan_trace(sites_dir, "池写入失败：%s" % exc)
        return False


def _pan_read_site_file(path):
    """读源写在 site 里的凭证；不是 JSON 对象就当没有（别把坏文件搬进池）。"""
    try:
        if os.path.getsize(path) <= 0:
            return None
        with open(path, encoding="utf-8", errors="replace") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def pan_vault_import(sites_dir, quiet=True):
    """把各站点已有的凭证收进池（首次运行即把用户此前的登录捞进来）。

    按 mtime 取最新：同一个盘在几个源里登录过，留最近那次。
    """
    root = jarsites_dir(sites_dir)
    vault = pan_vault_load(sites_dir)
    accounts = vault["accounts"]
    changed = 0
    if not os.path.isdir(root):
        return 0
    for name in os.listdir(root):
        d = os.path.join(root, name, _PAN_SUBDIR)
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            brand = _PAN_BY_FILE.get(fn)
            if not brand:
                continue
            p = os.path.join(d, fn)
            obj = _pan_read_site_file(p)
            if obj is None:
                continue
            try:
                mt = int(os.path.getmtime(p))
            except Exception:
                continue
            cur = accounts.get(brand) or {}
            if mt <= int(cur.get("at") or 0):
                continue
            accounts[brand] = {"json": obj, "at": mt, "from": name}
            changed += 1
            if not quiet:
                _pan_trace(sites_dir, "回收 %s ← %s（%s）" % (brand, name, fn))
    if changed:
        pan_vault_save(sites_dir, vault)
        if quiet:
            _pan_trace(sites_dir, "首次导入：%d 个账号进池（%s）" % (
                changed, ", ".join(sorted(accounts))))
    return changed


def pan_vault_reap(work_dir, sites_dir):
    """站点停下 → 把源新写/改过的凭证回收进池（源扫码成功的战果别丢）。"""
    d = os.path.join(work_dir, _PAN_SUBDIR)
    if not os.path.isdir(d):
        return 0
    vault = pan_vault_load(sites_dir)
    accounts = vault["accounts"]
    changed = 0
    for fn in os.listdir(d):
        brand = _PAN_BY_FILE.get(fn)
        if not brand:
            continue
        p = os.path.join(d, fn)
        obj = _pan_read_site_file(p)
        if obj is None:
            continue
        try:
            mt = int(os.path.getmtime(p))
        except Exception:
            continue
        cur = accounts.get(brand) or {}
        if mt <= int(cur.get("at") or 0):
            continue
        accounts[brand] = {"json": obj, "at": mt, "from": os.path.basename(work_dir)}
        changed += 1
        _pan_trace(sites_dir, "回收 %s ← %s" % (brand, os.path.basename(work_dir)))
    if changed:
        pan_vault_save(sites_dir, vault)
    return changed


def pan_vault_seed(work_dir, sites_dir):
    """站点启动前：把池投影成该源认识的文件（源读到就等于「已登录」）。

    两条规矩：
      · **只补不抢**：站点上的文件比池新，说明源自己有更新的（刚扫码），保留；
      · 写完把 mtime 设回池的 `at` —— 否则下次回收会把自己刚写的当成「源写的」，
        池的时间戳被一路推新，永远收不到源真正的新凭证（会抖动）。
    """
    vault = pan_vault_load(sites_dir)
    accounts = vault.get("accounts") or {}
    if not accounts:
        return 0
    d = os.path.join(work_dir, _PAN_SUBDIR)
    wrote = 0
    for brand, item in accounts.items():
        fn = _PAN_FILES.get(brand)
        if not fn or not isinstance(item, dict) or not item.get("json"):
            continue
        at = int(item.get("at") or 0)
        p = os.path.join(d, fn)
        try:
            if os.path.exists(p):
                if int(os.path.getmtime(p)) >= at:
                    continue  # 站点上的更新，留着
                site_obj = _pan_read_site_file(p)
                if site_obj == item["json"]:
                    # 内容一样、只是时间戳落后：对齐时间戳，不重写
                    os.utime(p, (at, at))
                    continue
            os.makedirs(d, exist_ok=True)
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(item["json"], f, ensure_ascii=False)
            os.replace(tmp, p)
            os.utime(p, (at, at))
            wrote += 1
            _pan_trace(sites_dir, "投影 %s → %s" % (
                brand, os.path.basename(work_dir)))
        except Exception as exc:
            _pan_trace(sites_dir, "投影 %s 失败：%s" % (brand, exc))
    return wrote


# 上次检查池子的时刻（节流用）。请求很密，没必要每次都扫一遍各站点的 ext。
_PAN_AT = [0.0]


def _pan_refresh(jvm, sites_dir):
    """已有 JVM：池子比这台的 ext 新就补写，真补了才重启（重启很贵）。

    为什么必须重启：源的 `init()` 只把凭证读进内存一次，文件改了它不会自己
    重新读。用户扫完码切到别的源，期望「立刻能用」，所以这里代它重来一次。
    """
    now = time.time()
    if now - _PAN_AT[0] < 10:
        return
    _PAN_AT[0] = now
    try:
        pan_vault_import(sites_dir)
        wrote = pan_vault_seed(jvm.work, sites_dir)
    except Exception:
        return
    if not wrote:
        return
    if jvm.proc is None or not jvm.ready:
        return  # 还没起或正在起，start 里已经投影过，不必再动
    _pan_trace(sites_dir, "池子有新凭证（%d 个），重启 JVM 让源重读" % wrote)
    try:
        jvm.restart()
    except Exception as exc:
        _pan_trace(sites_dir, "重启失败：%s" % exc)


# --------------------------------------------------------------------------
# 站点清单
# --------------------------------------------------------------------------

def load_sites(sites_dir, force=False):
    """扫 `wmdata/jarsites/*/sites.json`，返回 {站点 key: spec}。

    60 秒内的重复调用直接走缓存 —— 站点请求很密，没必要每次都扫盘。
    """
    global _SITES, _SITES_AT
    with _LOCK:
        now = time.time()
        if not force and _SITES and now - _SITES_AT < 60:
            return _SITES
        out = {}
        root = jarsites_dir(sites_dir)
        if os.path.isdir(root):
            for name in os.listdir(root):
                mf = os.path.join(root, name, "sites.json")
                if not os.path.isfile(mf):
                    continue
                try:
                    with open(mf, encoding="utf-8") as f:
                        data = json.load(f)
                except Exception:
                    continue
                jar = os.path.join(root, name, data.get("jar") or "spider.jar")
                for s in (data.get("sites") or []):
                    s = dict(s)
                    s["_jar"] = jar
                    s["_dir"] = os.path.join(root, name)
                    out[str(s.get("key"))] = s
        _SITES = out
        _SITES_AT = now
        return out


# --------------------------------------------------------------------------
# jar 转换（dex -> classes + assets）
# --------------------------------------------------------------------------

def ensure_jar(raw):
    """把 dex jar 转成 SpiderRunner 能直接吃的 jar（带缓存）。

    ★两步都不能省：dex2jar 的产物**不含 assets/*.so**，而加固壳（摸鱼的
      FishGuard）在 Init 阶段要加载它们，缺了就退化成「爬虫组件加载中」的
      空结果；DexJarRepair 是 Win-Box 同款步骤，修加固壳的 DEX 构造器。
    """
    d = os.path.dirname(os.path.abspath(raw))
    out = os.path.join(d, "spider.full.jar")
    try:
        sig = hashlib.md5(open(raw, "rb").read()).hexdigest()
    except Exception:
        return None
    mark = os.path.join(d, "spider.full.sig")
    if os.path.exists(out) and os.path.exists(mark):
        try:
            with open(mark, encoding="utf-8") as f:
                if f.read().strip() == sig:
                    return out
        except Exception:
            pass
    rt = _RT[0]
    if not rt or not rt.get("d2j"):
        # 没有 dex2jar 就原样喂（SpiderRunner 也许能自己转，死马当活马医）。
        return raw
    tmp = os.path.join(tempfile.gettempdir(), "jarsite_%d.jar" % os.getpid())
    try:
        subprocess.run(
            [rt["java"], "-Xmx2g", "-cp", os.path.join(rt["d2j"], "*"),
             "com.googlecode.dex2jar.tools.Dex2jarCmd", "--force", "-o", tmp, raw],
            capture_output=True, timeout=300, **_SPAWN)
        if rt.get("bridge"):
            d2j_cp = _d2j_cp(rt)
            subprocess.run(
                [rt["java"], "-Xmx384m", "-XX:+UseSerialGC", "-XX:TieredStopAtLevel=1",
                 "-Dfile.encoding=UTF-8", "-cp", rt["bridge"] + ";" + d2j_cp,
                 "com.winbox.nativebridge.DexJarRepair",
                 os.path.abspath(raw), tmp, rt["java"], d2j_cp],
                capture_output=True, timeout=300, **_SPAWN)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zo:
            with zipfile.ZipFile(tmp) as zp:
                for it in zp.infolist():
                    if it.filename.startswith("META-INF/"):
                        continue
                    zo.writestr(it, zp.read(it.filename))
            with zipfile.ZipFile(raw) as zr:
                for it in zr.infolist():
                    if it.filename.startswith(("assets/", "lib/")):
                        zo.writestr(it, zr.read(it.filename))
        with open(mark, "w", encoding="utf-8") as f:
            f.write(sig)
        return out
    except Exception:
        return raw
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass


# --------------------------------------------------------------------------
# 宿主侧代理转发（JVM 把请求绕回 9978 再回自己）
# --------------------------------------------------------------------------

_NO_PROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class _HubHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    # 裸 `/proxy?...` 的转发目标（本 runner 的 JVM 代理端口）。每个 runner
    # 用 type() 造自己的 handler 子类，互不串线。
    default_pport = 0

    def log_message(self, *a):
        pass

    def _out(self, code, ctype, body, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        for k, v in (extra or {}).items():
            if k.lower() == "content-length":
                continue  # 已经发过，重复的 Content-Length 会被客户端当成畸形包
            self.send_header(k, v)
        self.end_headers()
        if getattr(self, "_head_only", False):
            return
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_HEAD(self):
        # ★第 198 批：HEAD 不能带 body（老实现直接复用 do_GET，等于把整段
        #   内容也写一遍）。内核探测长度时会先发 HEAD，写错会把连接搞乱。
        self._head_only = True
        try:
            self.do_GET()
        finally:
            self._head_only = False

    def do_GET(self):
        path, _, query = self.path.partition("?")
        if path.startswith("/proxy/"):
            tail = path[len("/proxy/"):]
            if not tail.isdigit():
                self._out(400, "text/plain", b"bad port")
                return
            self._forward(int(tail), query)
            return
        if path == "/proxy":
            # 裸 `/proxy?...`（第 159 批）：源 jar 里 `Proxy.getUrl()` 拼出来
            # 的就是这种形态（`http://127.0.0.1:<hub>/proxy?do=xxx`）。
            # `do=ck` 是它开机时的探针：回 `ok` 才认这个端口是本地代理。
            # ★不回 `ok` 的后果很重 —— jar 会把 9978..9999 全扫一遍找应答
            #   的端口，这台机器上每个拒绝端口要磨约 2 秒，21 个端口 =
            #   **每次点播固定卡 30 秒**（Win-Box 秒开就是因为它 9978 上
            #   有应答的服务，扫描第一格就命中）。hub 占进扫描段后第一格
            #   之外的 9979 就能命中，扫描瞬间结束。
            if "do=ck" in query:
                self._out(200, "text/plain; charset=utf-8", b"ok")
                return
            if self.default_pport > 0:
                self._forward(self.default_pport, query)
                return
        self._out(404, "text/plain", b"not found")

    def _forward(self, port, query):
        target = "http://127.0.0.1:%d/proxy%s" % (
            port, ("?" + query) if query else "")
        hdrs = {}
        for h in ("range", "if-range", "accept", "user-agent", "referer"):
            v = self.headers.get(h)
            if v:
                hdrs[h] = v
        try:
            up = _NO_PROXY.open(
                urllib.request.Request(target, headers=hdrs, method="GET"),
                timeout=60)
        except Exception:
            self._out(502, "text/plain", b"jvm proxy unreachable")
            return
        # ★★第 198 批：**边读边写**，绝不能 `up.read()` 读完再发。
        #
        #   播放器（mpv / mdk，蜂蜜同款内核）第一笔请求就是开放式 Range
        #   `bytes=0-` —— 语义是「把剩下的全给我」。老实现先把整段读进内存，
        #   于是 1.16 GB 的 4K 原画要等它读完才有第一个字节，客户端 12 秒后
        #   超时、连响应头都收不到。用户看到的就是「网盘类源扫码成功也不能播」
        #   （实测：JVM 的 19987 直连 206 正常吐数据，经 hub 的 9979 转发则
        #   0 字节超时）。蜂蜜（TVBox 系）能播，因为它的本机代理就是
        #   InputStream → OutputStream 的循环转发，这里照它改。
        try:
            passthru = {}
            for k in ("Content-Type", "Content-Length", "Content-Range",
                      "Accept-Ranges", "ETag", "Last-Modified",
                      "Content-Disposition"):
                v = up.headers.get(k)
                if v:
                    passthru[k] = v
            self.send_response(up.status)
            self.send_header("Access-Control-Allow-Origin", "*")
            for k, v in passthru.items():
                self.send_header(k, v)
            # 上游没给长度（chunked / 边转边给）→ 只能靠关连接告诉客户端「完了」。
            if "Content-Length" not in passthru:
                self.send_header("Connection", "close")
                self.close_connection = True
            self.end_headers()
            if getattr(self, "_head_only", False):
                return
            while True:
                chunk = up.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            # 客户端拖进度条 / 关播放器会直接断开：静默收尾，别往 stderr 刷栈。
            self.close_connection = True
        except Exception:
            self.close_connection = True
        finally:
            try:
                up.close()
            except Exception:
                pass


def _free_port(preferred, tries=40):
    for i in range(tries):
        p = preferred + i
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", p))
            return p
        except OSError:
            continue
        finally:
            s.close()
    return 0


def _start_hub(pport=0):
    # ★第 159 批：优先占 9979..9999 —— 源 jar 的 `Proxy.getUrl()` 开机会扫
    #   127.0.0.1:9978..9999 找「本地代理」（/proxy?do=ck 回 ok 才认）。
    #   桥占了 9978 但不会回 ok；hub 若还挂在 19978 段，这个扫描永远扫空，
    #   而这台机器上每个拒绝端口要磨约 2 秒 → **每次点播固定多卡 30 秒**
    #   （Win-Box 快、我们慢的分水岭就在这一格）。hub 占进扫描段后扫描
    #   第一轮就命中，30 秒消失。
    port = _free_port(9979)
    if not port:
        port = _free_port(19978)
    if not port:
        return 0, None
    # 每个 runner 一份 handler 子类：裸 /proxy 的转发目标各指各的 JVM。
    handler = type(
        "_HubHandler%d" % port, (_HubHandler,), {"default_pport": pport})
    srv = ThreadingHTTPServer(("127.0.0.1", port), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return port, srv


def _proxy_port(cp, base=19970, span=30):
    """复刻 Win-Box 的 spiderProxyPort()：由 classpath 派生 JVM 侧代理端口。"""
    h = 0
    for ch in cp:
        h = (h * 31 + ord(ch)) | 0
        h = h - 0x100000000 if h > 0x7FFFFFFF else h
    return base + (h & 0xFFFFFFFF) % span


# --------------------------------------------------------------------------
# 一个 jar 一个 JVM
# --------------------------------------------------------------------------

_RT = [None]

## spider jar 里类的默认包名（TVBox 约定）。
_PKG = "com.github.catvod.spider."


class JarJvm:
    def __init__(self, jar, rt, sites_dir=None):
        self.jar = jar
        self.rt = rt
        # ★第 187 批：账号池要知道 wmdata 在哪（站点启动前投影、停下后回收）
        self.sites_dir = sites_dir
        self.proc = None
        self.seq = 0
        self.ready = False
        self.err = ""
        # 守卫预热是否已经做过（不管有没有等到放行）—— 只做一次（第 143 批）。
        self._warmed = False
        self.work = os.path.dirname(os.path.abspath(jar))
        self._names = None
        self._resolved = {}
        # ★★第 148 批：**一个进程只能有一个 stdout 读者**。
        #   以前是「谁发请求谁 readline」，桥是 ThreadingHTTPServer、每个
        #   站点一个线程 —— 两个站点同时请求时，A 会读到 B 的响应（id 对
        #   不上就丢掉），随后双方互等对方已经读走的那一行，**永久卡死**。
        #   实测 4 个站点并发：1 个拿到别人的响应，3 个永远停在 readline
        #   （JVM 还活着，但对这份 jar 的所有站点不再回应）。用户看到的就是
        #   「切几个站之后全部站源拉取失败」，而且重启 App 也没用 —— 桥是
        #   常驻进程，卡死的 JVM 一直在那儿。
        #   现在由 `_pump` 独占读，按 id 投递给各自的等待队列。
        self._wlock = threading.Lock()    # 写 stdin 必须原子
        self._qlock = threading.Lock()    # 在途请求表
        self._queues = {}                 # id -> queue.Queue
        self._reader = None
        # 连续「无响应」次数：够了就认定 JVM 卡死，重启它（见 call）。
        self._fails = 0
        # 本 runner 的宿主转发 hub（start 时创建，stop 时关闭，防端口泄漏）。
        self._hub_srv = None
        # JVM 的 stderr 落盘句柄（第 164 批）。
        self._errlog = None

    # -- 类名归一 -----------------------------------------------------------
    def _zip_names(self):
        if self._names is None:
            try:
                self._names = set(zipfile.ZipFile(self.jar).namelist())
            except Exception:
                self._names = set()
        return self._names

    def resolve(self, cls):
        """把订阅里写的 api（`csp_Xxx`）翻译成 jar 里真正的类名。

        ★第 141 批：SpiderRunner 是裸 `Class.forName(cls)`，不做任何前缀
          处理，所以两个约定必须在这里抹平 ——

          · 类**不一定**在默认包：绝大多数 spider jar 把它放在
            `com.github.catvod.spider.` 下（摸鱼的 1378 个类全在这个包里），
            直接传 `csp_PianDan` 必然 ClassNotFoundException，而且**不报错
            在明面上** —— 每个方法都超时，首页一直空，最容易被误判成
            「这个 jar 跑不起来」。
          · `csp_` 只是订阅里的写法前缀，不是类名的一部分，要剥掉。

          两种布局都试一遍（默认包优先，兼容老式 jar），都没命中就原样传，
          让 SpiderRunner 的异常回到日志里。
        """
        hit = self._resolved.get(cls)
        if hit:
            return hit
        out = cls
        names = self._zip_names()
        if names:
            base = cls[4:] if cls.startswith("csp_") else cls
            if cls.startswith(_PKG):
                # ★第 143 批：站点清单里写的常常是**已经拼好包名**的
                # `com.github.catvod.spider.csp_PianDan`（Dart 侧 jarClassName
                # 拼出来的），而 jar 里真正存在的是 `…spider.PianDan` ——
                # 不剥这层 csp_ 就是 ClassNotFoundException，表现为「首页
                # 秒回 0 条」（has_class 直接拦掉），比超时还难查。
                tail = cls[len(_PKG):]
                cands = (_PKG + (tail[4:] if tail.startswith("csp_") else tail),
                         cls)
            elif "." not in cls:
                cands = (_PKG + base, _PKG + cls, base)
            else:
                # 别的包名：原样，外加「同包剥 csp_」那一版。
                head, _, tail = cls.rpartition(".")
                cands = (cls, head + "." + (tail[4:] if tail.startswith("csp_")
                                            else tail))
            for cand in cands:
                if cand.replace(".", "/") + ".class" in names:
                    out = cand
                    break
        self._resolved[cls] = out
        return out

    def has_class(self, cls):
        """jar 里到底有没有这个类（没有就别去调，省一次 60 秒超时）。"""
        names = self._zip_names()
        if not names:
            return True  # 读不到 jar 就不拦，交给 SpiderRunner 报异常
        return self.resolve(cls).replace(".", "/") + ".class" in names

    # -- 启动 ---------------------------------------------------------------
    def _argv(self):
        rt = self.rt
        # ★蜘蛛 jar 绝不进 -cp：URLClassLoader 父优先会返回未改写的
        #   FishNative（native 声明 → register() UnsatisfiedLinkError
        #   → 守卫永远 pending）。这是第 136 批最大的一个坑。
        # ★netfix 必须在最前：它覆盖 okhttp3.OkHttpClient，让源的
        #   readTimeout(30s) 变成 90s。后面 libs/* 里的原版 okhttp 是兜底
        #   （补丁只替换 OkHttpClient 一个类，其余仍用官方 jar）。
        cp = ";".join([p for p in (
            rt.get("netfix"), rt.get("shim"), rt.get("stubs"),
            rt.get("compat"),
            (rt.get("libs") or "") + "/*" if rt.get("libs") else "",
            rt.get("bridge"),
            (rt.get("unidbg") or "") + "/*" if rt.get("unidbg") else "",
        ) if p])
        for sub in ("sandbox", "patch", "work", "runtime-dex"):
            os.makedirs(os.path.join(self.work, sub), exist_ok=True)
        pport = _free_port(_proxy_port(cp))
        hub, hub_srv = _start_hub(pport)
        if not hub:
            self.err = "起不来宿主转发端口"
            return None
        self._hub_srv = hub_srv
        return [
            # ★第 194 批：堆 384m → 768m。摸鱼这种一次挂 102 个站点的订阅，
            #   384m 里要装一百多个 Spider 实例 + 各自的 okhttp 连接池 +
            #   gson 树，GC 一抖就体现成「点开一个站要等十几秒」。
            #   每个 jar 一座 JVM（不是每个站），用户机 15G 内存，768m 有余量；
            #   要压内存可以设环境变量 WMYS_JVM_HEAP=384m。
            rt["java"], "-noverify", _heap_arg(), "-XX:+UseSerialGC",
            "-Dtvbox.spiderCacheDir=" + os.path.join(self.work, "sandbox"),
            # ★第 165 批：源的 cookie 落盘走
            # `new File(Environment.getExternalStorageDirectory(), "TVBox")`。
            # 桩以前把它指到 %TEMP%/tvbox-ext —— 一台机器上所有 jar 站点
            # 共用一份（百度/夸克会互相串味），而且 Temp 会被清理。
            # 现在按站点给目录：work/ext，跟着站点数据走。
            "-Dwmys.extdir=" + os.path.join(self.work, "ext"),
            "--add-opens=java.base/java.lang=ALL-UNNAMED",
            "--add-opens=java.base/java.lang.reflect=ALL-UNNAMED",
            "--add-opens=java.base/java.lang.invoke=ALL-UNNAMED",
            "--add-opens=java.base/java.util=ALL-UNNAMED",
            "--add-opens=java.base/java.util.concurrent=ALL-UNNAMED",
            "--add-opens=java.base/java.io=ALL-UNNAMED",
            "--add-opens=java.base/java.net=ALL-UNNAMED",
            "--add-opens=java.base/java.nio=ALL-UNNAMED",
            "--add-opens=java.base/java.security=ALL-UNNAMED",
            "--add-opens=java.base/java.text=ALL-UNNAMED",
            "--add-opens=java.base/sun.net.www.protocol.jar=ALL-UNNAMED",
            "-Dfile.encoding=UTF-8", "-Dsun.stdout.encoding=UTF-8",
            "-Dsun.stderr.encoding=UTF-8",
            "-Dtvbox.native.patch=" + os.path.join(self.work, "patch"),
            "-Dtvbox.native.work=" + os.path.join(self.work, "work"),
            "-Dtvbox.d2j.java=" + rt["java"],
            "-Dtvbox.d2j.cp=" + _d2j_cp(rt),
            "-Dtvbox.d2j.cache=" + os.path.join(self.work, "runtime-dex"),
            "-Dtvbox.proxy.port=%d" % pport,
            "-Dtvbox.proxy.entry=http://127.0.0.1:%d/proxy/%d" % (hub, pport),
            "-cp", cp, "SpiderRunner", "--serve", self.jar,
        ]

    def start(self):
        argv = self._argv()
        if not argv:
            return False
        # ★第 187 批：**JVM 起来之前**把账号池投影进本源的 ext/TVBox ——
        #   源的 init() 只读一次凭证，起完再写就晚了。投影失败不影响启动。
        if self.sites_dir:
            try:
                pan_vault_import(self.sites_dir)   # 先把别的源登录过的收进池
                pan_vault_seed(self.work, self.sites_dir)
            except Exception as exc:
                _pan_trace(self.sites_dir, "启动前投影异常：%s" % exc)
        # ★第 164 批：JVM 的 stderr 以前丢 DEVNULL —— 源里 NoSuchMethodError
        # / NoSuchFieldError 这类冲击全被吞掉，界面上只表现为「点了没反应」，
        # 日志里一个字都没有（潇洒配置中心「设置百度Cookie」就是栽在这上面）。
        # 现在落 `work/jvm.err.log`（重启时追加，超过 1MB 自动滚一份）。
        try:
            errpath = os.path.join(self.work, "jvm.err.log")
            if os.path.exists(errpath) and os.path.getsize(errpath) > 1024 * 1024:
                try:
                    os.replace(errpath, errpath + ".old")
                except Exception:
                    pass
            self._errlog = open(errpath, "ab")
        except Exception:
            self._errlog = None
        try:
            # stdin/stdout 用管道：本进程一死管道就关，SpiderRunner 读到 EOF
            # 自己退出，不会留孤儿 java.exe。
            self.proc = subprocess.Popen(
                argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=self._errlog or subprocess.DEVNULL, cwd=self.work,
                text=True,
                encoding="utf-8", errors="replace", bufsize=1, **_SPAWN)
        except Exception as e:
            self.err = "JVM 起不来：%s" % e
            return False
        # ★第 190 批：挂进「桥一死就整组收尸」的 Job（详见 _assign_to_job）。
        _assign_to_job(self.proc)
        # 落一份 pid，桥下次启动时据此认领上一轮的孤儿（reap_orphan_jvms）。
        try:
            with open(os.path.join(self.work, "jvm.pid"), "w") as fh:
                fh.write(str(self.proc.pid))
        except Exception:
            pass
        # ★读线程独占 stdout（第 148 批，见 __init__ 里的说明）。
        with self._qlock:
            self._queues.clear()
        self._reader = threading.Thread(
            target=self._pump, args=(self.proc,), daemon=True)
        self._reader.start()
        # 新进程 = 守卫要重新预热（否则重启后第一批请求会拿到 guard pending
        # 直接当失败），失败计数也归零。
        self._warmed = False
        self._fails = 0
        return True

    def _pump(self, proc):
        """唯一的 stdout 读者：按 id 把响应投给对应的等待者。

        ★绝不能退化成「请求线程自己 readline」（第 148 批）—— 响应是按行
          到达的，谁先读到就算谁的，id 一错位两边就永久互等。
        """
        try:
            for raw in iter(proc.stdout.readline, ""):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    env = json.loads(raw)
                except Exception:
                    continue
                with self._qlock:
                    waiter = self._queues.pop(str(env.get("id")), None)
                if waiter is not None:
                    data = env.get("data", "")
                    # 统一成文本（第 148 批）：Java 侧有时把数据当对象塞进
                    # `data`，有时当字符串 —— 下游一律按 JSON 文本处理。
                    if not isinstance(data, str):
                        try:
                            data = json.dumps(data, ensure_ascii=False)
                        except Exception:
                            data = str(data)
                    waiter.put(data)
                # 没有等待者 = 迟到的响应（调用方已超时），直接丢掉，
                # 千万别当下一笔请求的结果。
        except Exception:
            pass
        finally:
            # 进程没了：唤醒所有还在等的请求，别让它们耗满超时。
            with self._qlock:
                waiters = list(self._queues.values())
                self._queues.clear()
            for waiter in waiters:
                waiter.put(None)

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    # -- 调用 ---------------------------------------------------------------
    def _send(self, cls, method, args, timeout=60):
        """发一笔请求并等它自己的响应（第 148 批重写）。

        ★不再自己 readline：先把自己的 id 登记到 `_queues`，写请求行，
          然后只等自己那个队列 —— 别人的响应由 `_pump` 投给别人，互不干扰；
          超时也真的超时（以前 `readline()` 是阻塞的，超时判断永远轮不上）。
        """
        proc = self.proc
        if proc is None or proc.poll() is not None:
            return None
        waiter = queue.Queue()
        with self._qlock:
            self.seq += 1
            rid = str(self.seq)
            self._queues[rid] = waiter
        req = {"id": rid, "className": cls, "method": method, "args": args}
        try:
            line = json.dumps(req, ensure_ascii=False) + "\n"
            with self._wlock:
                proc.stdin.write(line)
                proc.stdin.flush()
        except Exception:
            with self._qlock:
                self._queues.pop(rid, None)
            return None
        try:
            return waiter.get(timeout=timeout)
        except queue.Empty:
            with self._qlock:
                self._queues.pop(rid, None)
            return None

    def _warm(self, spec):
        """守卫预热：JVM 起来后守卫要约 3 秒才就绪，第一次调用必须等它。

        ★必须拿 homeContent 当探针，不能用业务方法本身 —— 守卫未就绪时
          searchContent 之类一直拿不到有效响应，用它预热会永远等不到就绪。

        ★★第 143 批：**只预热一次，且有总时限**。以前写的是「最多 12 轮」，
          每轮一次 60 秒超时的探针 + 1.2 秒退避 —— 守卫没在这 12 轮里放行时
          一轮就是 30 多秒，而且 `ready` 一直是 false，**每个站点都要再等
          一轮**：用户看到的就是「激活进度条一直跑」「首页半天出不来」。
          现在总共只等 15 秒，等不到也放行（[call] 自己还会重试一次带
          守卫字样的响应，多数情况下那时其实已经可用了）。

        ★★第 147 批：**返回值要把「还没就绪」和「永久 pending」分开**。
          守卫刚起来那 1~2 秒也会回 pending，所以不能看到一次就判死；
          但连续 3 次（约 3 秒）都是 pending 就说明这份 jar 的壳我们适配
          不了 —— 这时候不该陪着等满 15 秒，而是让上层立刻回退 jar。
          返回 `"ok"` / `"pending"` / `"unknown"`（超时没结论）。
        """
        cls = self.resolve(spec["class"])
        deadline = time.time() + 15.0
        pending = 0
        while time.time() < deadline:
            data = self._send(cls, "homeContent", [spec.get("ext", "")],
                              timeout=18)
            mark = _guard_state(data)
            # 有数据、且跟守卫无关 = 真的能用。
            if data and mark is None:
                self.ready = True
                return "ok"
            # 守卫明确放行（`{"hostAdmission":"ok"}`）也算。
            if mark == "ok":
                self.ready = True
                return "ok"
            if mark == "pending":
                pending += 1
                if pending >= 3:
                    return "pending"
            else:
                pending = 0
            time.sleep(1.0)
        return "unknown"

    def call(self, spec, method, args):
        if not self.alive() and not self.start():
            return None
        # ★预热只做一次（第 143 批）：成败都置位，否则守卫若一直没放行，
        #   每个站点都要再吃一轮 15 秒预热 —— 首页等于永远出不来。
        if not self._warmed:
            self._warmed = True
            self._warm(spec)
        _t0 = time.time()
        data = self._roundtrip(self.resolve(spec["class"]), method, args)
        if os.environ.get("WMYS_JARSITE_DEBUG"):
            proc = self.proc
            sys.stderr.write(
                "[jarsite-dbg] %s %s.%s → data=%r / %.0f ms alive=%s fails=%d\n"
                % (os.path.basename(self.jar), spec.get("class", "?"), method,
                   None if data is None else len(data),
                   (time.time() - _t0) * 1000,
                   proc is not None and proc.poll() is None, self._fails))
        # ★★第 184 批：**空响应 ≠ 没响应**。以前这里用 `if not data` 判失败，
        #   于是「源回了空字符串」也被当成 JVM 卡死：
        #     · 潇洒配置中心的 `action()` 永远返回 ""（fire-and-forget，
        #       弹窗走 /hook/ui）→ 每点一下设置就 +1 失败；
        #     · 连点两下清除 Cookie → 失败数到 2 → **JVM 被重启**。
        #   用户看到的就是：点了清除没反应 / 窗关了要等一会儿 / 昨天扫的码
        #   今天变「未登录」（源写 cookie 走 Handler 异步线程，JVM 一重启
        #   那条链连同扫码轮询一起没了）。现在只有 `None`（真超时）才算失败。
        if data is None:
            # ★★第 148 批：一点回应都没有 = JVM 卡死或崩了。以前这里直接
            #   返回 None，于是**整份 jar 的所有站点**一起「拉取失败」，用户
            #   只能重启 App —— 而桥是常驻进程，重启 App 也不管用。现在连续
            #   两次没回应就重启 JVM 再试一次（`start` 会把守卫预热标记复位，
            #   重启后重新过守卫）。
            self._fails += 1
            if self._fails >= 2:
                sys.stderr.write(
                    "[jarsite] JVM 连续 %d 次无响应，重启：%s\n"
                    % (self._fails, os.path.basename(self.jar)))
                self.restart()
                if self.alive():
                    self._warmed = True
                    self._warm(spec)
                    data = self._roundtrip(
                        self.resolve(spec["class"]), method, args)
        else:
            self._fails = 0
        if not data:
            return None
        try:
            return json.loads(data)
        except Exception:
            return None

    def _roundtrip(self, cls, method, args):
        """一次往返（守卫还没放行就等 1 秒再来一次，最多两次）。"""
        data = ""
        for i in range(2):
            data = self._send(cls, method, args)
            if data is None:
                break
            if _guard_state(data) is None:
                break
            if i == 0:
                time.sleep(1.0)
        # 两次都还被守卫拦着 = 这份 jar 现在出不了数据，别把守卫串当结果
        # 往下传（那会变成「0 条」而不是「失败」，反而更难查）。
        if _guard_state(data) is not None:
            return ""
        return data

    def stop(self):
        p = self.proc
        if p is None:
            return
        try:
            p.stdin.write("quit\n")
            p.stdin.flush()
        except Exception:
            pass
        try:
            p.wait(timeout=5)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
        self.proc = None
        # 进程没了，pid 文件也别留着（它在磁盘上就是给「下次启动认领孤儿」用的）。
        try:
            os.remove(os.path.join(self.work, "jvm.pid"))
        except Exception:
            pass
        # 关掉 stderr 句柄，别在重启时攒一堆文件描述符。
        errlog = getattr(self, "_errlog", None)
        self._errlog = None
        if errlog is not None:
            try:
                errlog.close()
            except Exception:
                pass
        # JVM 没了，它的转发 hub 也一起关（以前每次 restart 都泄漏一个端口）。
        srv = self._hub_srv
        self._hub_srv = None
        if srv is not None:
            try:
                srv.shutdown()
            except Exception:
                pass
        # ★第 187 批：JVM 已经死了，它写的凭证文件不会再变 —— 这是回收最安全
        #   的时刻（源扫码成功后写的就是这些文件），收进池后别的源下次启动即有。
        if self.sites_dir:
            try:
                pan_vault_reap(self.work, self.sites_dir)
            except Exception as exc:
                _pan_trace(self.sites_dir, "停止后回收异常：%s" % exc)

    def restart(self):
        """杀掉并重起 JVM（卡死 / 崩溃后的唯一活路，第 148 批）。

        ★用户看到的「切几个站之后全部站源拉取失败、重启 App 也没用」就是
          卡死的 JVM 一直活着：桥是常驻进程，App 退出它也不退，那份卡死的
          java.exe 还在池子里被所有站点共用。这里主动换一个干净进程。
        """
        try:
            self.stop()
        except Exception:
            pass
        self.err = ""
        return self.start()


def _jvm_for(spec, sites_dir):
    # ★转换串行（第 146 批）：dex2jar + DexJarRepair 要 90 多秒，两个站点
    #   同时冷启动会各跑一遍、还往同一个 spider.full.jar 写 —— 一是白等，
    #   二是可能写坏。锁只包转换，命中缓存时就是读一个 sig 文件。
    with _CONV_LOCK:
        jar = ensure_jar(spec["_jar"])
    if not jar:
        return None
    with _LOCK:
        jvm = _POOL.get(jar)
        if jvm is None:
            global _RT
            if _RT[0] is None:
                _RT[0] = find_runtime(sites_dir)
            if not _RT[0]:
                return None
            jvm = JarJvm(jar, _RT[0], sites_dir)
            _POOL[jar] = jvm
            fresh = True
        else:
            fresh = False
    # ★第 187 批：JVM 可能早就起着（别的站点先访问过），而用户刚在另一个源
    #   里扫码登录 —— 这时池子是新的、这台的 ext 还是旧的。每 10 秒查一次：
    #   真补写了凭证就重启这台 JVM（源的 init 只读一次凭证，不重启看不到新号）。
    #   刻意放在锁外：restart 要几秒，不能攥着 _LOCK 卡住所有站点的请求。
    if not fresh:
        _pan_refresh(jvm, sites_dir)
    return jvm


## 已经试过回退的 jar（一次运行只试一次，别在坏 jar 上反复折腾）。
_ROLLED = set()


def _md5_file(path):
    try:
        with open(path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()
    except Exception:
        return ""


def _known_good_path(jar):
    """`wmdata/jarsites/_known-good/spider.jar` —— 全机共用的一份「验过的 jar」。

    ★为什么要有它（第 147 批）：`spider.jar.prev` 只有在「本地已经有 jar」时
      才会存在。用户新建一条 jar 订阅时是**第一次下载**，本地什么都没有 ——
      偏偏这时候下到的就是换了壳的新 jar，pending 之后无路可退（日志里那句
      「没有上一版 jar 可回退」）。所以把每次**守卫验过**的 jar 存一份到这里，
      它就是所有订阅目录的公共退路。
    """
    if not jar:
        return None
    d = os.path.dirname(os.path.abspath(jar))
    base = os.path.dirname(d)
    return os.path.join(base, "_known-good", "spider.jar")


def remember_good(jar, sites_dir=None):
    """守卫验过的 jar 存一份到 `_known-good`（md5 没变就不重复拷）。"""
    try:
        d = os.path.dirname(os.path.abspath(jar)) if jar else (
            os.path.abspath(sites_dir) if sites_dir else "")
        if not d:
            return False
        src = os.path.join(d, "spider.jar")
        if not os.path.exists(src):
            return False
        dst = _known_good_path(src)
        if not dst:
            return False
        src_md5 = _md5_file(src)
        if not src_md5:
            return False
        if os.path.exists(dst) and _md5_file(dst) == src_md5:
            return True
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        tmp = dst + ".tmp"
        shutil.copy2(src, tmp)
        os.replace(tmp, dst)
        with open(dst + ".md5", "w", encoding="utf-8") as f:
            f.write(src_md5)
        sys.stderr.write("[jarsite] 记下一份可用 jar（%s → _known-good）\n"
                         % src_md5[:12])
        return True
    except Exception as e:
        sys.stderr.write("[jarsite] 记录可用 jar 失败：%s\n" % e)
        return False


def rollback_jar(jar):
    """守卫过不去时换回上一版 jar（第 146 批）。

    ★为什么要这一步：上游推的新 jar 换了壳（FishGuard-v8 新版），我们这边的
      宿主适配（native patch + unidbg 应答）跟不上，97 个站点会**全部**回
      `hostAdmission: pending`。用户看到的是「一直加载 / 宿主校验未通过」，
      而且重新启用订阅也没用 —— App 会再把这份新 jar 下回来。
    App 每次下载新 jar 前会把上一份留成 `spider.jar.prev`，这里就地把 prev
    换回来，并清掉按 jar 内容做的转换缓存（`spider.full.jar` / `patch/`），
    下一次调用会重新转换。
    """
    if not jar:
        return False
    key = os.path.abspath(jar)
    d = os.path.dirname(key)
    # ★去重按 md5 而不是路径（第 147 批）：路径在回退前后都一样，按路径记的话
    #   用户后来又下了一份坏 jar 就再也回退不了了。
    token = _md5_file(os.path.join(d, "spider.jar")) or key
    with _LOCK:
        if token in _ROLLED:
            return False
    prev = os.path.join(d, "spider.jar.prev")
    # ★没有 prev 时退到全机共用的 `_known-good`（第 147 批）：新建订阅是
    #   第一次下 jar，本地没有「上一版」，这时唯一的退路就是它。
    kg = _known_good_path(os.path.join(d, "spider.jar"))
    source = prev if os.path.exists(prev) else (
        kg if kg and os.path.exists(kg) else None)
    if source is None:
        sys.stderr.write(
            "[jarsite] 守卫 pending，但这台机器上没有上一版 jar 可回退"
            "（%s）\n" % d)
        return False
    try:
        # ★顺序要紧（第 146 批实测）：JVM 打开着 `spider.full.jar`，Windows 下
        #   它一占用就删不掉（WinError 32）。所以**先停 JVM 再动文件** ——
        #   反过来的话回退永远失败，而且失败后 jar 已经被换掉、缓存还是旧的。
        with _LOCK:
            doomed = [
                v for k, v in _POOL.items()
                if os.path.dirname(os.path.abspath(k)) == d
            ]
            for k in [k for k in _POOL if os.path.dirname(os.path.abspath(k)) == d]:
                _POOL.pop(k, None)
        for jvm in doomed:
            try:
                jvm.stop()
            except Exception:
                pass
        shutil.copy2(key, key + ".rejected")
        if source == prev:
            os.replace(prev, key)
        else:
            # known-good 是全机共用的，不能搬走，只能拷。
            shutil.copy2(source, key)
        for name in ("spider.full.jar", "spider.full.sig"):
            p = os.path.join(d, name)
            if not os.path.exists(p):
                continue
            for _ in range(6):
                try:
                    os.remove(p)
                    break
                except OSError:
                    time.sleep(0.5)  # 等系统真正放开句柄
        shutil.rmtree(os.path.join(d, "patch"), ignore_errors=True)
        with _LOCK:
            _ROLLED.add(token)
        sys.stderr.write(
            "[jarsite] 守卫 pending：已回退到上一版 jar（%s），重新转换中\n" % d)
        return True
    except Exception as e:
        sys.stderr.write("[jarsite] 回退 jar 失败：%s\n" % e)
        return False


# --------------------------------------------------------------------------
# 给 bridge.py 用的 Spider 适配器
# --------------------------------------------------------------------------

## ★第 189 批：`xxx_status` 动作的盘名对照（兜底提示用）。
_STATUS_NAMES = {
    "quark": "夸克网盘", "uc": "UC 网盘", "baidu": "百度网盘",
    "ali": "阿里云盘", "aliyun": "阿里云盘", "tianyi": "天翼云盘",
    "yidong": "移动云盘", "xunlei": "迅雷云盘", "pan123": "123 云盘",
    "pan115": "115 网盘", "guangya": "光鸭网盘", "bili": "哔哩合集",
}
# 动作名 → 账号池/凭证文件的品牌 key（池子只有 7 个标准盘）。
_STATUS_BRAND_KEY = {
    "ali": "aliyun", "aliyun": "aliyun", "tianyi": "tianyi",
    "yidong": "yidong", "pan123": "pan123", "pan115": "pan115",
}


def _pan_brand_key(name):
    """动作名里的盘名 → 账号池的品牌 key（`ali` → `aliyun` …）。"""
    return _STATUS_BRAND_KEY.get(name, name)


def _pan_login_state(self, key):
    """某个盘的登录状态：`(是否登录, 昵称)`。

    先看**本站点** `ext/TVBox/<文件>`（源刚扫码写的就是它），再回落到账号池。
    第 189 批：面板、状态文案、扫完码的自动收尾都读这一处，别各写一套。
    """
    fn = _PAN_FILES.get(key)
    if fn and getattr(self, "ext", ""):
        obj = _pan_read_site_file(os.path.join(self.ext, _PAN_SUBDIR, fn))
        if isinstance(obj, dict):
            nick = str(obj.get("nickname") or obj.get("name")
                       or obj.get("nick_name") or obj.get("user_name") or "")
            return True, nick
    try:
        vault = pan_vault_load(self.sites_dir)
    except Exception:
        return False, ""
    item = (vault.get("accounts") or {}).get(key)
    if isinstance(item, dict) and item.get("json"):
        obj = item.get("json") or {}
        nick = str(obj.get("nickname") or obj.get("name")
                   or obj.get("nick_name") or obj.get("user_name") or "")
        if not nick:
            try:
                at = int(item.get("at") or 0)
                if at > 0:
                    nick = time.strftime("%m-%d %H:%M", time.localtime(at))
            except Exception:
                pass
        return True, nick
    return False, ""


def _pan_status_card(self, brand):
    """`xxx_status` 的兜底答案：账号池 + 本站点凭证文件拼一句当前状态。

    背景（★189 取证）：Fish 系源的「当前状态」建窗方法（merge.z.e3.a()）
    是 dex2jar 转坏的交错跳转字节码，缺栈映射帧 —— JVM 带着 -noverify
    时坏帧一路进 JIT，点一下就把整个 JVM 原生崩掉（hs_err：e3.a()+352，
    android-handler 线程），窗没弹、事件全丢，App 只剩「源没有返回执行
    结果」。这类字节码 ASM 重算帧也修不好（跳转交错、帧不可推导），
    所以在源头拦：动作返回空且 JVM 已经死了，就用账号池给一句能看的。
    """
    name = _STATUS_NAMES.get(brand, brand)
    logged, nick = _pan_login_state(self, _pan_brand_key(brand))
    if logged:
        tail = "（%s）" % nick if nick else ""
        return {"msg": "%s：已登录%s。可在 设置 → 网盘账号 里管理。" % (name, tail)}
    return {"msg": "%s：未登录 —— 到配置中心点「扫码登录」，手机确认后这里就会亮。" % name}



class JarSpider:
    """把 jar 里的蜘蛛类伪装成一个 py 源 Spider。

    方法签名照 TVBox 的约定写，bridge 的 `call_spider` 会按签名裁参数。
    """

    def __init__(self, key, spec, sites_dir):
        self.key = key
        self.spec = spec
        self.sites_dir = sites_dir
        self.ext = spec.get("ext") or ""

    def init(self, ext=None):
        # 桥会带一次 ext 过来（可能为空）；清单里那份才是订阅写死的，优先。
        if ext and not self.ext:
            self.ext = ext

    def warm(self):
        """把这份 jar 的冷启动提前做掉（第 146 批）。

        ★为什么必须有一个显式的预热入口：jar 的冷启动要 dex2jar 转换 +
          DexJarRepair 修壳 + 起 JVM + 守卫就绪，实测 **98 秒**。以前这段
          全压在第一次 `homeContent` 里，而 App 侧的 home 请求只等 45 秒 ——
          用户看到的就是「一直加载，最后拉取失败」，其实再等一会儿就好了。
          现在 App 会在激活订阅后并发调一次 `init`（超时放宽到 4 分钟），
          转换在这里做完，之后点站点是秒级。

        ★★第 147 批：返回值从 `bool` 改成状态串 —— App 拿它当「激活是否
          真的能出数据」的判据，不再只看「桥起来了」就报「N 个站点已就绪」。
          `"pending"` 时这里顺手做一次 jar 回退 + 重试，回退成功就返回
          `"ok"`，App 那边看到的是「换回上一版后正常」。
        """
        if _RT[0] is None:
            _RT[0] = find_runtime(self.sites_dir)
        if not _RT[0]:
            return "noenv"
        jvm = _jvm_for(self.spec, self.sites_dir)
        if jvm is None:
            return "nojar"
        if not jvm.alive() and not jvm.start():
            return "noenv"
        with _LOCK:
            first = not jvm._warmed
            if first:
                jvm._warmed = True
        state = jvm._warm(self.spec) if first else (
            "ok" if jvm.ready else "unknown")
        if state == "pending":
            # 守卫连续 pending = 这份 jar 的壳我们不认，就地换回上一版再来。
            if rollback_jar(self.spec.get("_jar")) or rollback_jar(jvm.jar):
                again = _jvm_for(self.spec, self.sites_dir)
                if again is not None and again is not jvm:
                    if not again.alive() and not again.start():
                        return "pending"
                    state = again._warm(self.spec)
                    if state == "ok":
                        remember_good(again.jar, self.sites_dir)
                        sys.stderr.write(
                            "[jarsite] 已换回上一版 jar 并恢复正常（%s）\n"
                            % os.path.dirname(again.jar))
                        return "ok"
            return "pending"
        if state == "ok":
            remember_good(jvm.jar, self.sites_dir)
        return state

    def _call(self, method, extra=None):
        # ★没装组件就明确报「没装」（第 144 批）：以前会掉进 `jvm is None`
        # 直接返回 {}，界面上就是一片空白，看不出是没环境还是源坏了。
        if _RT[0] is None:
            _RT[0] = find_runtime(self.sites_dir)
        if not _RT[0]:
            raise RuntimeError(
                "jar 运行环境未安装 —— 打开 设置 → 组件 → jar 源运行时，"
                "点「导入组件包」选 jarspider-runtime-*.zip（约 97 MB）")
        jvm = _jvm_for(self.spec, self.sites_dir)
        if jvm is None:
            raise RuntimeError(
                "jar 没就位（%s 下载或转换失败，详见 wmdata\\subscription.log）"
                % os.path.basename(self.spec.get("_jar") or "spider.jar"))
        if not jvm.has_class(self.spec["class"]):
            # 类名对不上时 SpiderRunner 回的是异常串，界面上只表现为「一直空」；
            # 这里直接说清楚是哪个类，别让人对着空首页猜。
            #
            # ★第 194 批：从「静默回空」改成**抛错**。用户报「摸鱼大部分站源
            #   不能播放」，实测 102 站里有 13 站（开饭/歇会/发呆/晃悠/随缘/
            #   躺平/赖床/板凳/慢点/知我/等风/流映/打盹）订阅写的是
            #   `csp_KaiFan` 这类类名，**当前 jar 里根本没有这个类** ——
            #   以前这里 `return {}`，界面只显示「该分类暂无内容」，看着就像
            #   「源坏了、播不了」，用户根本不知道原因。现在把话说到明面上，
            #   App 的「拉取失败」会把这句话原样显示出来。
            cls = self.spec["class"]
            sys.stderr.write("[jarsite] %s 里没有 %s（可用类名在 "
                             "com.github.catvod.spider. 下）\n"
                             % (jvm.jar, cls))
            raise RuntimeError(
                "这个源在当前 jar 里没有实现（找不到类 %s）。"
                "订阅里的站点比 jar 新 —— 点一次「刷新订阅」重新拉 jar；"
                "要是刷新后还是这句，就是旧 jar 里确实没这个站，等源作者更新。"
                % cls.split(".")[-1])
        args = [self.ext] + [str(x) for x in (extra or [])]
        out = jvm.call(self.spec, method, args) or {}
        # ★守卫过不去 = 这份 jar 的壳我们适配不了（第 146 批）：与其让 97 个
        #   站点各转 40 秒再回一条假条目，不如当场换回上一版 jar 再试一次。
        if isinstance(out, dict) and out.get(_GUARD) == "pending":
            if rollback_jar(self.spec.get("_jar")) or rollback_jar(jvm.jar):
                again = _jvm_for(self.spec, self.sites_dir)
                if again is not None and again is not jvm:
                    retry = again.call(self.spec, method, args) or out
                    return _explain_pending(retry, again.jar)
        return _explain_pending(out, jvm.jar)

    def homeContent(self, filter=True):
        return self._call("homeContent")

    def homeVideoContent(self):
        return self._call("homeVideoContent")

    def categoryContent(self, tid, pg, filter=True, extend=None):
        # ★第 197 批：`extend` 以前直接被丢掉，第 4 段永远传空串。
        #   SpiderRunner 的协议是 `args = [ext, tid, pg, "k=v&k2=v2"]`（摸鱼
        #   自带的 fish-* 插件也是这么调的），第 4 段按 `&` 拆、按 `=` 分键值、
        #   再过一次 URLDecode 成 HashMap。我们一直传空 → 源拿到的筛选条件
        #   永远是空 map。三六影视就是栽在这：它的分类 URL 要用 rank/cat/area
        #   这些筛选值拼，空着拼出来的地址缺参数，接口回空 —— 界面上表现为
        #   「首页 35 条、点进分类一片空白」，耗时还只有 1ms。
        pairs = []
        if isinstance(extend, dict):
            for k, v in extend.items():
                if v in (None, ""):
                    continue
                pairs.append(
                    "%s=%s"
                    % (quote(str(k), safe=""), quote(str(v), safe="")))
        return self._call("categoryContent", [tid, pg, "&".join(pairs)])

    def detailContent(self, ids):
        joined = ",".join(str(x) for x in (ids if isinstance(ids, list) else [ids]))
        return self._call("detailContent", [joined])

    def searchContent(self, key, quick=False, pg="1"):
        return self._call("searchContent", [key, pg])

    def playerContent(self, flag, id, vipFlags=None):
        v = vipFlags or []
        joined = ",".join(str(x) for x in v) if isinstance(v, list) else str(v)
        out = self._call("playerContent", [flag, id, joined])
        # ★第 195 批：源里 `playerContent` 自己抛异常时，SpiderRunner 回的是
        #   空对象，界面只剩一句「该集未取到播放地址」—— 看不出是源的锅。
        #   热播 APP 就是这么栽的：它的播放项是 `url|密钥|签名|UA||剧名|集数`，
        #   源第一句 `split('|')` 取第 2/3/5/6 段，段数不够就数组越界，
        #   9 毫秒回空。这里至少把「谁、哪条线路、id 多长」记进 stderr，
        #   并给界面一句能照着做的话。
        if not out:
            sys.stderr.write(
                "[jarsite] %s.playerContent 回空（flag=%s，id %d 字符）\n"
                % (self.spec["class"].split(".")[-1], flag, len(str(id))))
            return {
                "parse": 0,
                "url": "",
                "msg": "源没给出播放地址（这条线路在源内部取流失败）—— 换一条线路试试，"
                       "还不行就是这个源的播放项格式没对上",
            }
        return out

    def action(self, raw, vid=""):
        """源内动作（第 162 批）：转给 JVM 里的 `spider.action`。

        对齐 TVBox / 蜂蜜的 ActionCardHelper：「设置中心」那类条目点开时
        不进详情、不搜索，而是把动作卡原文交给源自己执行。新版壳是
        `action(String)`，老 TVBox 壳是 `action(String, String)` ——
        Java 侧反射两签各试一次，这里固定传 (动作原文, 条目 id)。
        返回按约定是 JSON（`{"type":…}` / `{"msg":…}` / `{"list":[…]}`）；
        非文本 JSON 会被 `_call` 吞成 {}，由上层落回提示语。

        ★第 189 批：`xxx_status` 兜底 —— Fish 系源「当前状态」的建窗字节码
        是坏的（缺栈映射帧），一调就把 JVM 原生崩掉，窗没弹、事件全丢。
        识别特征：响应为空 + JVM 刚死。这时别让用户对着「源没有返回执行
        结果」发懵，用账号池拼一句当前状态回去（JVM 下次调用会自动重启）。
        """
        raw = str(raw or "")
        out = self._call("action", [raw, vid])
        m = re.fullmatch(r"([a-z0-9]+)_status", raw.strip(), re.I)
        if m and not out:
            # 崩在源的异步窗线程（android-handler），action 本身可能先返回 ——
            # 给崩溃半秒到一秒半的落地时间再判。
            jvm = _POOL.get(ensure_jar(self.spec["_jar"]))
            if jvm is not None:
                for _ in range(6):
                    if not jvm.alive():
                        try:
                            return _pan_status_card(self, m.group(1).lower())
                        except Exception:
                            break
                    time.sleep(0.25)
        return out

    # ------------------------------------------------------------ 网盘登录
    #
    # ★第 189 批：网盘源「没登录 → 直接弹扫码窗」的闭环。
    #
    # 分工：
    #   · 本文件负责**认出该调谁**（同订阅里的设置中心站点）和**动作名**
    #     （`<盘>_scan`）；真正弹窗还是源自己那一套，事件经 /hook/ui 回到 App。
    #   · bridge 负责把这次动作期间冒出来的 UI 事件一起捎回去；
    #   · App 负责画窗、并把「登录成功」翻译成关窗 + 重试播放。
    #
    # 为什么不是在本站点上调 `quark_scan`：实测 玩偶 4K（jar_2bc1b7b6902c）
    # 的 action 只回 `{}`（源里那个类根本没实现扫码入口），而同一个 jar 的
    # 「设置中心」站点（jar_20c79f622648）认 `quark_scan`。同一份 jar 共用
    # 一个 JVM 和同一个 work/ext，扫出来的凭证写进 ext/TVBox 后，玩偶 4K
    # 下次取流就能读到 —— 所以跨站点代按是安全的。

    def _pan_config_site(self):
        """本订阅里「设置中心 / 配置中心」那个站点（扫码入口在它身上）。"""
        try:
            sites = load_sites(self.sites_dir)
        except Exception:
            return None
        mine = self.spec.get("_dir") or ""
        for key, spec in sites.items():
            if (spec.get("_dir") or "") != mine:
                continue
            flat = re.sub(r"[\s┆•·|｜/／\-—_]+", "", str(spec.get("name") or ""))
            if ("设置" in flat or "配置" in flat) and "中心" in flat:
                return spec
        return None

    def pan_state(self):
        """所有标准盘的登录状态：`{品牌: {logged, nick}}`（不碰 JVM）。"""
        out = {}
        for key in _PAN_FILES:
            try:
                logged, nick = _pan_login_state(self, key)
            except Exception:
                logged, nick = False, ""
            if logged:
                out[key] = {"logged": True, "nick": nick}
        return out

    def pan_scan(self, brand):
        """给「网盘没登录」拉一次扫码窗，返回 `{ok, target, action, msg}`。

        `brand` 可以是动作名里的写法（`ali` / `quark`），也可以是池子的
        品牌 key（`aliyun`）—— 两套写法都收。
        """
        key = _pan_brand_key(str(brand or "").strip().lower())
        name = _STATUS_NAMES.get(key, key)
        logged, nick = _pan_login_state(self, key)
        if logged:
            tail = "（%s）" % nick if nick else ""
            return {"ok": True, "logged": True, "target": self.key,
                    "action": "",
                    "msg": "%s 已经是登录状态%s，正在重试播放。" % (name, tail)}
        cfg = self._pan_config_site() or self.spec
        target = JarSpider(cfg.get("key") or self.key, cfg, self.sites_dir)
        acts = ["%s_scan" % key]
        raw_brand = str(brand or "").strip().lower()
        if raw_brand and raw_brand != key:
            acts.insert(0, "%s_scan" % raw_brand)
        err = ""
        for act in acts:
            try:
                target.action(act)
            except Exception as exc:
                err = str(exc)
                continue
            # 动作本身回什么是次要的（源把窗画在 Dialog 里，返回值常年是
            # 空串）；能不能出窗由 bridge 数 UI 事件来判断。
            return {"ok": True, "logged": False,
                    "target": cfg.get("key") or self.key,
                    "action": act, "msg": ""}
        return {"ok": False, "logged": False, "target": cfg.get("key") or self.key,
                "action": "", "msg": err or ("这个源没有 %s 的扫码入口" % name)}


## 守卫放行前的占位响应（Java 侧给的原文，第 143 批改成能看懂的话）。
_PENDING_TEXT = (
    "订阅方这份 jar 的宿主校验没通过（新版壳），本机出不了数据。"
    "桥已尝试自动换回上一版 jar；若还是这样，说明本机没有可回退的旧 jar —— "
    "把订阅里的 jar 地址换成上一版，或关掉「自动跟进 jar 更新」后重新导入。"
)


def _explain_pending(out, jar):
    """守卫没放行时把话说清楚（第 143 批）。

    摸鱼 10-21 那份 jar 的守卫永远 `pending`：Java 侧回的是一条
    「宿主验证未就绪，请稍候」的占位条目，界面上看着像「还在加载」，
    其实等再久也不会有数据 —— 用户就只能对着转圈猜。这里把占位条目
    换成一句能照着做的话，并往 stderr 记一笔（桥日志里能查到）。
    """
    if not isinstance(out, dict) or out.get("hostAdmission") != "pending":
        return out
    sys.stderr.write(
        "[jarsite] 守卫 pending（%s）：这份 jar 的宿主校验过不去，"
        "站点不会有数据\n" % jar)
    out["list"] = [{
        "vod_id": "__host_pending__",
        "vod_name": "宿主校验未通过，这个源现在出不了数据",
        "vod_remarks": _PENDING_TEXT,
        "vod_content": _PENDING_TEXT,
    }]
    return out


def make_spider(key, sites_dir):
    """bridge.get_spider 里 `jar_` 前缀的分支入口。"""
    spec = load_sites(sites_dir).get(key)
    if not spec:
        raise RuntimeError("jar 站点清单里没有这个 key：" + key)
    return JarSpider(key, spec, sites_dir)


def shutdown_all():
    with _LOCK:
        for jvm in _POOL.values():
            try:
                jvm.stop()
            except Exception:
                pass
        _POOL.clear()
